from __future__ import print_function
from ortools.linear_solver import pywraplp
import random
from yafs.selection import Selection
import networkx as nx
from collections import defaultdict

class MinimunPath(Selection):


    def __init__(self):
        self.rr = {}  # for a each type of service, we have a mod-counter
        self.messages_affected = []
        



        self.controller_seonsor = {101: 1, 102: 1, 103: 1, 104: 1, 105: 1, 106: 5, 107: 5, 108: 5, 109: 5, 110: 5, 111: 11, 112: 11, 113: 11, 114: 11,
                                   115: 11, 116: 16, 117: 16, 118: 16, 119: 16, 120: 16, 121: 22, 122: 22, 123: 22, 124: 22, 125: 22, 126: 27, 127: 27,
                                   128: 27, 129: 27, 130: 27, 131: 34, 132: 34, 133: 34, 134: 34, 135: 34, 136: 39, 137: 39, 138: 39, 139: 39, 140: 39,
                                   141: 42, 142: 42, 143: 42, 144: 42, 145: 42, 146: 47, 147: 47, 148: 47, 149: 47, 150: 47, 151: 52, 152: 52, 153: 52,
                                   154: 52, 155: 52, 156: 57, 157: 57, 158: 57, 159: 57, 160: 57, 161: 62, 162: 62, 163: 62, 164: 62, 165: 62, 166: 65,
                                   167: 65, 168: 65, 169: 65, 170: 65, 171: 70, 172: 70, 173: 70, 174: 70, 175: 70, 176: 76, 177: 76, 178: 76, 179: 76,
                                   180: 76, 181: 80, 182: 80, 183: 80, 184: 80, 185: 80, 186: 86, 187: 86, 188: 86,
                                   189: 86, 190: 86, 191: 91, 192: 91, 193: 91, 194: 91, 195: 91, 196: 96, 197: 96, 198: 96, 199: 96, 200: 96}






        self.sensor_nodes = {128: [6, 7, 8, 9, 10], 129: [6, 7, 8, 9, 10], 130: [6, 7, 8, 9, 10], 131: [17, 18, 19, 20, 21], 132: [17, 18, 19, 20, 21],
                             133: [17, 18, 19, 20, 21], 134: [17, 18, 19, 20, 21], 135: [17, 18, 19, 20, 21],
                             141: [17, 18, 19, 20, 21, 12, 13, 14, 15, 35, 36, 37, 38, 71, 72, 73, 74, 75],
                             142: [17, 18, 19, 20, 21, 12, 13, 14, 15, 35, 36, 37, 38, 71, 72, 73, 74, 75],
                             143: [17, 18, 19, 20, 21, 12, 13, 14, 15, 35, 36, 37, 38, 71, 72, 73, 74, 75],
                             144: [17, 18, 19, 20, 21, 12, 13, 14, 15, 35, 36, 37, 38, 71, 72, 73, 74, 75],
                             145: [17, 18, 19, 20, 21, 12, 13, 14, 15, 35, 36, 37, 38, 71, 72, 73, 74, 75],
                             146: [43, 44, 45, 46, 66, 67, 68, 69, 23, 24, 25, 26, 53, 54, 55, 56],
                             147: [43, 44, 45, 46, 66, 67, 68, 69, 23, 24, 25, 26, 53, 54, 55, 56],
                             148: [43, 44, 45, 46, 66, 67, 68, 69, 23, 24, 25, 26, 53, 54, 55, 56],
                             149: [43, 44, 45, 46, 66, 67, 68, 69, 23, 24, 25, 26, 53, 54, 55, 56],
                             150: [43, 44, 45, 46, 66, 67, 68, 69, 23, 24, 25, 26, 53, 54, 55, 56],
                             151: [66, 67, 68, 69, 58, 59, 60, 61], 152: [66, 67, 68, 69, 58, 59, 60, 61], 153: [66, 67, 68, 69, 58, 59, 60, 61],
                             154: [66, 67, 68, 69, 58, 59, 60, 61], 155: [66, 67, 68, 69, 58, 59, 60, 61], 156: [63, 64], 157: [63, 64], 158: [63, 64],
                             159: [63, 64], 160: [63, 64], 161: [48, 49, 50, 51], 162: [48, 49, 50, 51], 163: [48, 49, 50, 51], 164: [48, 49, 50, 51],
                             165: [48, 49, 50, 51], 171: [43, 44, 45, 46, 58, 59, 60, 61], 172: [43, 44, 45, 46, 58, 59, 60, 61], 173: [43, 44, 45, 46, 58, 59, 60, 61],
                             174: [43, 44, 45, 46, 58, 59, 60, 61], 175: [43, 44, 45, 46, 58, 59, 60, 61], 176: [12, 13, 14, 15], 177: [12, 13, 14, 15], 178: [12, 13, 14, 15],
                             179: [12, 13, 14, 15], 180: [12, 13, 14, 15], 181: [17, 18, 19, 20, 21], 182: [17, 18, 19, 20, 21], 183: [17, 18, 19, 20, 21], 184: [17, 18, 19, 20, 21],
                             185: [17, 18, 19, 20, 21], 186: [28, 29, 30, 31, 32, 33], 187: [28, 29, 30, 31, 32, 33], 188: [28, 29, 30, 31, 32, 33], 189: [28, 29, 30, 31, 32, 33],
                             190: [28, 29, 30, 31, 32, 33], 191: [12, 13, 14, 15], 192: [12, 13, 14, 15], 193: [12, 13, 14, 15], 194: [12, 13, 14, 15], 195: [12, 13, 14, 15],
                             101: [77, 78, 79, 81, 82, 83, 84, 85], 102: [77, 78, 79, 81, 82, 83, 84, 85], 103: [77, 78, 79, 81, 82, 83, 84, 85], 104: [77, 78, 79, 81, 82, 83, 84, 85],
                             105: [77, 78, 79, 81, 82, 83, 84, 85], 106: [17, 18, 19, 20, 21, 97, 98, 99, 100], 107: [17, 18, 19, 20, 21, 97, 98, 99, 100],
                             108: [17, 18, 19, 20, 21, 97, 98, 99, 100], 109: [17, 18, 19, 20, 21, 97, 98, 99, 100], 110: [17, 18, 19, 20, 21, 97, 98, 99, 100],
                             111: [2, 3, 4, 17, 18, 19, 20, 21], 112: [2, 3, 4, 17, 18, 19, 20, 21], 113: [2, 3, 4, 17, 18, 19, 20, 21],
                             114: [2, 3, 4, 17, 18, 19, 20, 21], 115: [2, 3, 4, 17, 18, 19, 20, 21], 116: [23, 24, 25, 26, 6, 7, 8, 9, 10, 28, 29, 30, 31, 32, 33],
                             117: [23, 24, 25, 26, 6, 7, 8, 9, 10, 28, 29, 30, 31, 32, 33], 118: [23, 24, 25, 26, 6, 7, 8, 9, 10, 28, 29, 30, 31, 32, 33],
                             119: [23, 24, 25, 26, 6, 7, 8, 9, 10, 28, 29, 30, 31, 32, 33], 120: [23, 24, 25, 26, 6, 7, 8, 9, 10, 28, 29, 30, 31, 32, 33],
                             121: [28, 29, 30, 31, 32, 33, 40, 41, 35, 36, 37, 38, 87, 88, 89, 90], 122: [28, 29, 30, 31, 32, 33, 40, 41, 35, 36, 37, 38, 87, 88, 89, 90],
                             123: [28, 29, 30, 31, 32, 33, 40, 41, 35, 36, 37, 38, 87, 88, 89, 90], 124: [28, 29, 30, 31, 32, 33, 40, 41, 35, 36, 37, 38, 87, 88, 89, 90],
                             125: [28, 29, 30, 31, 32, 33, 40, 41, 35, 36, 37, 38, 87, 88, 89, 90], 126: [6, 7, 8, 9, 10], 127: [6, 7, 8, 9, 10]}



    def best_node(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic,alpha):
        node_src = sim.DES_msgs[message.id]
        controller = self.controller_seonsor[node_src]
        c_ips = sim.nodes_attributes[controller][3]



        DES_dst = alloc_module[app_name][message.dst]  # returns an array with all DES process serving
        inst = message.inst
        size = message.bytes

        req_cpu = message.CPU
        req_ram = message.RAM
        req_sc = message.SC
        max_delay = message.d
        
        req_pm = message.PM
        cpu=[]
        pm=[]
        ram=[]
        ipt=[]

        delays =[]

        links = []
        nodes = []
        waiting =[]
        waiting_at_controler = 0
        f2f = []

        linkdelay = sim.msgsAd[message.id] + sim.msgsBd[message.id]

        for m in sim.queue_at_controller[controller]:
            waiting_at_controler = waiting_at_controler+ 1000/c_ips
        for key in self.sensor_nodes.keys():
            if key == node_src:

                for item in self.sensor_nodes[key]:
                    w = 0.0
                    nodes.append(item)
                    link = (node_src,item)
                    if self.controller_seonsor[node_src] != item:
                        tran = (127/125000) / 600
                        pro = 1/600000
                        f2f.append((tran+pro)*2)
                    else:
                        f2f.append(0)
                    cpu.append(sim.nodes_attributes[item][0])
                    ram.append(sim.nodes_attributes[item][1])
                    pm.append(sim.nodes_attributes[item][2])
                    ipt.append(sim.nodes_attributes[item][3])
                    if len(sim.msgs_in_queues[item]) != 0:
                        # print("wee",sim.msgs_in_queues_ic[item])
                        for ic in sim.msgs_in_queues_ic[item]:

                            w = w + ic/sim.nodes_attributes[item][3]
                            # print("wee",w)

                    waiting.append(w)
                    links.append(link)
       

        for link in links:

            transmit = (float(message.bytes) / 125000) / (sim.topology.get_edge(link)['BW'])  # MBITS!

            propagation = float(sim.topology.get_edge(link)['PR'])
            latency_msg_link = transmit + propagation

            delays.append(latency_msg_link*2)
        
        for i in range(len(delays)):

            delays[i] = delays[i] + (inst/ float(ipt[i])) +1000/c_ips + waiting[i] + waiting_at_controler + linkdelay + f2f[i]




  
        solver = pywraplp.Solver('SolveIntegerProblem',
                                 pywraplp.Solver.CBC_MIXED_INTEGER_PROGRAMMING)
        x = []
        for i in range(len(nodes)): #x is number of nodes
            x.append(solver.IntVar(0.0, 1, 'x' + str(i)))

        constraint1 = solver.Constraint(-solver.infinity(), 1) #pick one node
        for i in range(len(x)):
            constraint1.SetCoefficient(x[i], 1)

        constraint2 = solver.Constraint(0, solver.infinity()) #doesn't exceed max allowed delay
        for i in range(len(x)):

            constraint2.SetCoefficient(x[i], float(max_delay) - delays[i])
        constraint3 = solver.Constraint(0, solver.infinity()) # satisfies the required cpu
        for i in range(len(x)):

            # print("cpu",cpu[i] - float(req_cpu))
            constraint3.SetCoefficient(x[i], cpu[i] - float(req_cpu))
        constraint4 = solver.Constraint(0, solver.infinity()) # satisfies the required ram
        for i in range(len(x)):
            # print("ram",ram[i] - float(req_ram))
            constraint4.SetCoefficient(x[i], ram[i] - float(req_ram))
        constraint5 = solver.Constraint(0, solver.infinity()) #satisfies privacy measure
        for i in range(len(x)):

            constraint5.SetCoefficient(x[i], pm[i] - float(req_pm))
        objective = solver.Objective()
        # print("msg",message.name)
        for i in range(len(x)):
            

            delay = float(max_delay) - delays[i]
            
            privacy = pm[i] - float(req_pm)
           

            coef = (delay *alpha) + (privacy*(1-alpha))
           

            objective.SetCoefficient(x[i],coef )


        #objective.SetCoefficient(x[len(x)-1], delays[len(delays)-1]) // for cloud

        objective.SetMaximization()
        result_status = solver.Solve()
        # The problem has an optimal solution.
        assert result_status == pywraplp.Solver.OPTIMAL

        # The solution looks legit (when using solvers other than
        # GLOP_LINEAR_PROGRAMMING, verifying the solution is highly recommended!).
        assert solver.VerifySolution(1e-7, True)

        # print('Number of variables =', solver.NumVariables())
        # print('Number of constraints =', solver.NumConstraints())

        # The objective value of the solution.
        # print('Optimal objective value = %d' % solver.Objective().Value())
        sid = -1
        # The value of each variable in the solution.
        variable_list = []
        counter = 0
        found = 0
        selected_node = -1
        for v in x:

            if v.solution_value() == 1:
                sid = counter
                found = 1
            counter+=1

        
        if found:
            selected_node =nodes[sid]
        elif req_sc == 1:
            selected_node =0
        
        sim.msg_to_bestnode[message.id] = selected_node


        DES_dst = alloc_module[app_name][message.dst]

        # print("GET PATH")

        # print("\tNode _ src (id_topology): %i" % node_src)
        # print("\tRequest service: %s " % message.dst)

        if "M.C" in message.name:
        
            try:
                sim.msgs_in_queues[selected_node].append(message.id)
                sim.msgs_in_queues_ic[selected_node].append(message.inst)
            except:
                print("nop")

        
        bestPath = []
        bestDES = []
        for des in DES_dst:  ## In this case, there are only one deployment
            if selected_node != -1:
                dst_node =selected_node

                path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))
                
                bestPath = [path]
                bestDES = [des]
     
        return bestPath, bestDES


    def get_path(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic):
        """
        Computes the minimun path among the source elemento of the topology and the localizations of the module

        Return the path and the identifier of the module deployed in the last element of that path
        """



        node_src = sim.msg_to_bestnode[message.id]
        if "M.D" in message.name:
      

            index = sim.msgs_in_queues[node_src].index(message.id)

            sim.msgs_in_queues[node_src].pop(index)
            sim.msgs_in_queues_ic[node_src].pop(index)

        DES_dst = alloc_module[app_name][message.dst]

        # print ("GET PATH")



        # print ("\tNode _ src (id_topology): %i" %node_src)
        # print ("\tRequest service: %s " %message.dst)

        bestPath = []
        bestDES = []

        for des in DES_dst: ## In this case, there are only one deployment
            # if dst_node == -1:
            
            dst_node = sim.DES_msgs[message.id]


            path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))
            # bestPath.append(path)
            # bestDES.append(des)
            bestPath = [path]
            bestDES = [des]

            



        return bestPath, bestDES

    def for_avg_delay(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic):
        """
        Computes the minimun path among the source elemento of the topology and the localizations of the module

        Return the path and the identifier of the module deployed in the last element of that path
        """
        possible = [6,7,8,9,10,12,13,14,15,16,17]
        i = random.randint(0,10)


        sim.msg_to_bestnode[message.id] = 13
        node_src = sim.DES_msgs[message.id]

        DES_dst = alloc_module[app_name][message.dst]

        # print ("GET PATH")



        # print ("\tNode _ src (id_topology): %i" %node_src)
        # print ("\tRequest service: %s " %message.dst)

        bestPath = []
        bestDES = []

        for des in DES_dst: ## In this case, there are only one deployment
            
            dst_node = 13

          
            path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))
            # bestPath.append(path)
            # bestDES.append(des)
            bestPath = [path]
            bestDES = [des]

           



        return bestPath, bestDES

    def cluster_deploy(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic):
        #sending request to the controller of the topology_src
        """
        Computes the minimun path among the source elemento of the topology and the localizations of the module

        Return the path and the identifier of the module deployed in the last element of that path
        """


        node_src = topology_src

        if (node_src in sim.population.get_src_ids()):
            sim.sources.append(node_src)


        DES_dst = alloc_module[app_name][message.dst]

        # print ("GET PATH")

        # print ("\tNode _ src (id_topology): %i" % node_src)
        # print ("\tRequest service: %s " % message.dst)

        bestPath = []
        bestDES = []

        for des in DES_dst:  ## In this case, there are only one deployment

            dst_node = self.controller_seonsor[node_src]

            path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))

            bestPath = [path]
            bestDES = [des]

        sim.queue_at_controller[dst_node].append(message.id)

        link = (node_src, self.controller_seonsor[node_src])
        transmit = (float(message.bytes) / 125000) / (sim.topology.get_edge(link)['BW'])  # MBITS!

        propagation = float(sim.topology.get_edge(link)['PR'])
        latency_msg_link = transmit + propagation
        sim.msgsAd[message.id] = latency_msg_link
        return bestPath, bestDES
    def request_reply(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic):
        #sending request to the controller of the topology_src
        """
        Computes the minimun path among the source elemento of the topology and the localizations of the module

        Return the path and the identifier of the module deployed in the last element of that path
        """

        node_src = sim.source_msgs[message.id]
        index = sim.queue_at_controller[node_src].index(message.id)
        sim.queue_at_controller[node_src].pop(index)
        if (node_src in sim.population.get_src_ids()):
            sim.sources.append(node_src)

        DES_dst = alloc_module[app_name][message.dst]

        # print ("GET PATH")

        # print ("\tNode _ src (id_topology): %i" % node_src)
        # print ("\tRequest service: %s " % message.dst)

        bestPath = []
        bestDES = []

        for des in DES_dst:  ## In this case, there are only one deployment


            dst_node = sim.DES_msgs[message.id]

            path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))

            bestPath = [path]
            bestDES = [des]
        link = (node_src,sim.DES_msgs[message.id])
        transmit = (float(message.bytes) / 125000) / (sim.topology.get_edge(link)['BW'])  # MBITS!

        propagation = float(sim.topology.get_edge(link)['PR'])
        latency_msg_link = transmit + propagation
        sim.msgsBd[message.id] = latency_msg_link

        return bestPath, bestDES


class MinPath_RoundRobin(Selection):

    def __init__(self):
        self.rr = {} #for a each type of service, we have a mod-counter

    def get_path(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic):
        """
        Computes the minimun path among the source elemento of the topology and the localizations of the module

        Return the path and the identifier of the module deployed in the last element of that path
        """
        node_src = topology_src

        DES_dst = alloc_module[app_name][message.dst] #returns an array with all DES process serving


        if message.dst not in self.rr.keys():
            self.rr[message.dst] = 0


        print ("GET PATH")
        print ("\tNode _ src (id_topology): %i" %node_src)
        print ("\tRequest service: %s " %(message.dst))
        print ("\tProcess serving that service: %s (pos ID: %i)" %(DES_dst,self.rr[message.dst]))

        bestPath = []
        bestDES = []

        for ix,des in enumerate(DES_dst):
            if message.name == "M.A":
                if self.rr[message.dst]==ix:
                    dst_node = alloc_DES[des]

                    path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))

                    bestPath = [path]
                    bestDES = [des]

                    self.rr[message.dst] = (self.rr[message.dst]+ 1) % len(DES_dst)
                    break
            else: #message.name == "M.B"

                dst_node = alloc_DES[des]

                path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))
                if message.broadcasting:
                    bestPath.append(path)
                    bestDES.append(des)
                else:
                    bestPath = [path]
                    bestDES = [des]

        return bestPath, bestDES