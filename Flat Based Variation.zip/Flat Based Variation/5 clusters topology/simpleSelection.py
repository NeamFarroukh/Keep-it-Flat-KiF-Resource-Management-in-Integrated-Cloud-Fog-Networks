from __future__ import print_function
from ortools.linear_solver import pywraplp
import random
from yafs.selection import Selection
import networkx as nx
from collections import defaultdict

class MinimunPath(Selection):


    def __init__(self):
        self.rr = {}  # for a each type of service, we have a mod-counter
        self.messages_affected = []
        # self.controller_seonsor = {1:5,9:5,8:3}
        # # self.controller_controller = {3: (5), 5: (3)}
        # self.sensor_nodes = {1: [6, 7], 8: [4, 6, 7],9:[4,6,7]}
        # # self.controller_nodes = {5: [6, 7], 3: [4]}


        #for my topology
        self.controller_seonsor = {27: 1, 28: 1, 29: 1, 30: 1, 31: 1, 32: 5, 33: 5, 34: 5, 35: 5, 36: 5, 37: 11, 38: 11,
                                  39: 11, 40: 11, 41: 11, 42: 16, 43: 16, 44: 16, 45: 16, 46: 16, 47: 22, 48: 22,
                                  49: 22, 50: 22, 51: 22}
        self.sensor_nodes = {32: [6, 7, 8, 9, 10, 17, 18, 19, 20, 21],
                             33: [12, 13, 14, 15, 2, 3, 4, 17, 18, 19, 20, 21],
                             34: [12, 13, 14, 15, 2, 3, 4, 17, 18, 19, 20, 21],
                             35: [12, 13, 14, 15, 2, 3, 4, 17, 18, 19, 20, 21],
                             36: [17, 18, 19, 20, 21, 23, 24, 25, 26, 6, 7, 8, 9, 10],
                             37: [17, 18, 19, 20, 21, 23, 24, 25, 26, 6, 7, 8, 9, 10],
                             38: [17, 18, 19, 20, 21, 23, 24, 25, 26, 6, 7, 8, 9, 10], 39: [23, 24, 25, 26],
                             40: [23, 24, 25, 26], 41: [23, 24, 25, 26], 27: [2, 3, 4], 28: [2, 3, 4], 29: [2, 3, 4],
                             30: [6, 7, 8, 9, 10, 17, 18, 19, 20, 21], 31: [6, 7, 8, 9, 10, 17, 18, 19, 20, 21]}
        # self.controller_seonsor = {23:1,24:1,25:1,26:5,27:5,28:5,29:11,30:11,31:11,32:18,33:18,34:18}
        # self.sensor_nodes = {23:[2,3,4],24:[2,3,4],25:[2,3,4],
        #                      26:[2,3,4,6,7,8,9,10],27:[2,3,4,6,7,8,9,10],28:[2,3,4,6,7,8,9,10],
        #                      29:[6,7,8,9,10,12,13,14,15,16,17],30:[6,7,8,9,10,12,13,14,15,16,17],31:[6,7,8,9,10,12,13,14,15,16,17],
        #                      32:[12,13,14,15,16,17,19,20,21,22], 33:[12,13,14,15,16,17,19,20,21,22], 34:[12,13,14,15,16,17,19,20,21,22]}



    def best_node(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic,alpha):
        node_src = sim.DES_msgs[message.id]
        controller = self.controller_seonsor[node_src]
        c_ips = sim.nodes_attributes[controller][3]



        DES_dst = alloc_module[app_name][message.dst]  # returns an array with all DES process serving
        inst = message.inst
        size = message.bytes

        req_cpu = message.CPU
        req_ram = message.RAM
        req_sc = message.SC
        max_delay = message.d
    
        req_pm = message.PM
        cpu=[]
        pm=[]
        ram=[]
        ipt=[]

        delays =[]

        links = []
        nodes = []
        waiting =[]
        waiting_at_controler = 0
        f2f = []

        linkdelay = sim.msgsAd[message.id] + sim.msgsBd[message.id]

        for m in sim.queue_at_controller[controller]:
            waiting_at_controler = waiting_at_controler+ 1000/c_ips
        for key in self.sensor_nodes.keys():
            if key == node_src:

                for item in self.sensor_nodes[key]:
                    w = 0.0
                    nodes.append(item)
                    link = (node_src,item)
                    if self.controller_seonsor[node_src] != item:
                        tran = (127/125000) / 600
                        pro = 1/600000
                        f2f.append((tran+pro)*2)
                    else:
                        f2f.append(0)
                    cpu.append(sim.nodes_attributes[item][0])
                    ram.append(sim.nodes_attributes[item][1])
                    pm.append(sim.nodes_attributes[item][2])
                    ipt.append(sim.nodes_attributes[item][3])
                    if len(sim.msgs_in_queues[item]) != 0:
                    
                        for ic in sim.msgs_in_queues_ic[item]:

                            w = w + ic/sim.nodes_attributes[item][3]
                            # print("wee",w)

                    waiting.append(w)
                    links.append(link)
      

        for link in links:

            transmit = (float(message.bytes) / 125000) / (sim.topology.get_edge(link)['BW'])  # MBITS!

            propagation = float(sim.topology.get_edge(link)['PR'])
            latency_msg_link = transmit + propagation

            delays.append(latency_msg_link*2)

        for i in range(len(delays)):

            delays[i] = delays[i] + (inst/ float(ipt[i])) +1000/c_ips + waiting[i] + waiting_at_controler + linkdelay + f2f[i]




       
        solver = pywraplp.Solver('SolveIntegerProblem',
                                 pywraplp.Solver.CBC_MIXED_INTEGER_PROGRAMMING)
        x = []
        for i in range(len(nodes)): #x is number of nodes
            x.append(solver.IntVar(0.0, 1, 'x' + str(i)))

        constraint1 = solver.Constraint(-solver.infinity(), 1) #pick one node
        for i in range(len(x)):
            constraint1.SetCoefficient(x[i], 1)

        constraint2 = solver.Constraint(0, solver.infinity()) #doesn't exceed max allowed delay
        for i in range(len(x)):

            constraint2.SetCoefficient(x[i], float(max_delay) - delays[i])
        constraint3 = solver.Constraint(0, solver.infinity()) # satisfies the required cpu
        for i in range(len(x)):

            constraint3.SetCoefficient(x[i], cpu[i] - float(req_cpu))
        constraint4 = solver.Constraint(0, solver.infinity()) # satisfies the required ram
        for i in range(len(x)):
    
            constraint4.SetCoefficient(x[i], ram[i] - float(req_ram))
        constraint5 = solver.Constraint(0, solver.infinity()) #satisfies privacy measure
        for i in range(len(x)):

            constraint5.SetCoefficient(x[i], pm[i] - float(req_pm))
        objective = solver.Objective()
        # print("msg",message.name)
        for i in range(len(x)):
          

            delay = float(max_delay) - delays[i]
           
            privacy = pm[i] - float(req_pm)
       

            coef = (delay *alpha) + (privacy*(1-alpha))
            

            objective.SetCoefficient(x[i],coef )


       

        objective.SetMaximization()
        result_status = solver.Solve()
    
        assert result_status == pywraplp.Solver.OPTIMAL

    
        assert solver.VerifySolution(1e-7, True)

        # print('Number of variables =', solver.NumVariables())
        # print('Number of constraints =', solver.NumConstraints())

        # The objective value of the solution.
        # print('Optimal objective value = %d' % solver.Objective().Value())
        sid = -1
   
        variable_list = []
        counter = 0
        found = 0
        selected_node = -1
        for v in x:

            if v.solution_value() == 1:
                sid = counter
                found = 1
            counter+=1

       
        if found:
            selected_node =nodes[sid]

       
        elif req_sc == 1:
          
            selected_node =0

    
        sim.msg_to_bestnode[message.id] = selected_node


        DES_dst = alloc_module[app_name][message.dst]

        # print("GET PATH")
        #
        # print("\tNode _ src (id_topology): %i" % node_src)
        # print("\tRequest service: %s " % message.dst)

        if "M.C" in message.name:
          
            try:
                sim.msgs_in_queues[selected_node].append(message.id)
                sim.msgs_in_queues_ic[selected_node].append(message.inst)
            except:
                print("nop")


        bestPath = []
        bestDES = []
        for des in DES_dst:  ## In this case, there are only one deployment
            if selected_node != -1:
                "eir"
                dst_node =selected_node

                path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))
                
                bestPath = [path]
                bestDES = [des]
     
        return bestPath, bestDES


    def get_path(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic):
        """
        Computes the minimun path among the source elemento of the topology and the localizations of the module

        Return the path and the identifier of the module deployed in the last element of that path
        """



        node_src = sim.msg_to_bestnode[message.id]
        if "M.D" in message.name:
            # print("lol",message.id)

            index = sim.msgs_in_queues[node_src].index(message.id)

            sim.msgs_in_queues[node_src].pop(index)
            sim.msgs_in_queues_ic[node_src].pop(index)

        DES_dst = alloc_module[app_name][message.dst]

        # print ("GET PATH")



        # print ("\tNode _ src (id_topology): %i" %node_src)
        # print ("\tRequest service: %s " %message.dst)

        bestPath = []
        bestDES = []

        for des in DES_dst: ## In this case, there are only one deployment
            # if dst_node == -1:
            
            dst_node = sim.DES_msgs[message.id]


           
            path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))
           
            bestPath = [path]
            bestDES = [des]

           



        return bestPath, bestDES

    def for_avg_delay(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic):
        """
        Computes the minimun path among the source elemento of the topology and the localizations of the module

        Return the path and the identifier of the module deployed in the last element of that path
        """
        possible = [6,7,8,9,10,12,13,14,15,16,17]
        i = random.randint(0,10)


        sim.msg_to_bestnode[message.id] = 13
        node_src = sim.DES_msgs[message.id]

        DES_dst = alloc_module[app_name][message.dst]


        bestPath = []
        bestDES = []

        for des in DES_dst: ## In this case, there are only one deployment
          
            dst_node = 13

          
            path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))
            # bestPath.append(path)
            # bestDES.append(des)
            bestPath = [path]
            bestDES = [des]

         



        return bestPath, bestDES

    def cluster_deploy(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic):
        #sending request to the controller of the topology_src
        """
        Computes the minimun path among the source elemento of the topology and the localizations of the module

        Return the path and the identifier of the module deployed in the last element of that path
        """


        node_src = topology_src

        if (node_src in sim.population.get_src_ids()):
            sim.sources.append(node_src)


        DES_dst = alloc_module[app_name][message.dst]

        # print ("GET PATH")

        # print ("\tNode _ src (id_topology): %i" % node_src)
        # print ("\tRequest service: %s " % message.dst)

        bestPath = []
        bestDES = []

        for des in DES_dst:  ## In this case, there are only one deployment

            dst_node = self.controller_seonsor[node_src]

            path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))

            bestPath = [path]
            bestDES = [des]

        sim.queue_at_controller[dst_node].append(message.id)

        link = (node_src, self.controller_seonsor[node_src])
        transmit = (float(message.bytes) / 125000) / (sim.topology.get_edge(link)['BW'])  # MBITS!

        propagation = float(sim.topology.get_edge(link)['PR'])
        latency_msg_link = transmit + propagation
        sim.msgsAd[message.id] = latency_msg_link
        return bestPath, bestDES
    def request_reply(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic):
        #sending request to the controller of the topology_src
        """
        Computes the minimun path among the source elemento of the topology and the localizations of the module

        Return the path and the identifier of the module deployed in the last element of that path
        """

        node_src = sim.source_msgs[message.id]
        index = sim.queue_at_controller[node_src].index(message.id)
        sim.queue_at_controller[node_src].pop(index)
        if (node_src in sim.population.get_src_ids()):
            sim.sources.append(node_src)

        DES_dst = alloc_module[app_name][message.dst]

        # print ("GET PATH")

        # print ("\tNode _ src (id_topology): %i" % node_src)
        # print ("\tRequest service: %s " % message.dst)

        bestPath = []
        bestDES = []

        for des in DES_dst:  ## In this case, there are only one deployment


            dst_node = sim.DES_msgs[message.id]

            path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))

            bestPath = [path]
            bestDES = [des]
        link = (node_src,sim.DES_msgs[message.id])
        transmit = (float(message.bytes) / 125000) / (sim.topology.get_edge(link)['BW'])  # MBITS!

        propagation = float(sim.topology.get_edge(link)['PR'])
        latency_msg_link = transmit + propagation
        sim.msgsBd[message.id] = latency_msg_link

        return bestPath, bestDES


class MinPath_RoundRobin(Selection):

    def __init__(self):
        self.rr = {} #for a each type of service, we have a mod-counter

    def get_path(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic):
        """
        Computes the minimun path among the source elemento of the topology and the localizations of the module

        Return the path and the identifier of the module deployed in the last element of that path
        """
        node_src = topology_src

        DES_dst = alloc_module[app_name][message.dst] #returns an array with all DES process serving


        if message.dst not in self.rr.keys():
            self.rr[message.dst] = 0


        print ("GET PATH")
        print ("\tNode _ src (id_topology): %i" %node_src)
        print ("\tRequest service: %s " %(message.dst))
        print ("\tProcess serving that service: %s (pos ID: %i)" %(DES_dst,self.rr[message.dst]))

        bestPath = []
        bestDES = []

        for ix,des in enumerate(DES_dst):
            if message.name == "M.A":
                if self.rr[message.dst]==ix:
                    dst_node = alloc_DES[des]

                    path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))

                    bestPath = [path]
                    bestDES = [des]

                    self.rr[message.dst] = (self.rr[message.dst]+ 1) % len(DES_dst)
                    break
            else: #message.name == "M.B"

                dst_node = alloc_DES[des]

                path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))
                if message.broadcasting:
                    bestPath.append(path)
                    bestDES.append(des)
                else:
                    bestPath = [path]
                    bestDES = [des]

        return bestPath, bestDES