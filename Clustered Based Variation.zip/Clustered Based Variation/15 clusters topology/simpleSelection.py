from __future__ import print_function
from ortools.linear_solver import pywraplp
import random
from yafs.selection import Selection
import networkx as nx
from collections import defaultdict

class MinimunPath(Selection):


    def __init__(self):
        self.rr = {}  # for a each type of service, we have a mod-counter
        self.messages_affected = []
        
        self.reach_clusters =  {128: [11, 14, 12], 129: [11, 14, 12], 130: [11, 14, 12], 131: [12, 13], 132: [12, 13],
                                133: [12, 13], 134: [12, 13], 135: [12, 13], 136: [13, 10], 137: [13, 10], 138: [13, 10],
                                139: [13, 10], 140: [13, 10], 141: [14], 142: [14], 143: [14], 144: [14], 145: [14],
                                146: [15, 9, 12], 147: [15, 9, 12], 148: [15, 9, 12], 149: [15, 9, 12], 150: [15, 9, 12],
                                76: [1], 77: [1], 78: [1], 79: [1], 80: [1], 81: [2, 4], 82: [2, 4], 83: [2, 4], 84: [2, 4],
                                85: [2, 4], 86: [3, 1, 4], 87: [3, 1, 4], 88: [3, 1, 4], 89: [3, 1, 4], 90: [3, 1, 4], 91: [4, 5, 2, 6],
                                92: [4, 5, 2, 6], 93: [4, 5, 2, 6], 94: [4, 5, 2, 6], 95: [4, 5, 2, 6], 96: [5, 6, 8, 7], 97: [5, 6, 8, 7],
                                98: [5, 6, 8, 7], 99: [5, 6, 8, 7], 100: [5, 6, 8, 7], 101: [6, 2], 102: [6, 2], 103: [6, 2], 104: [6, 2],
                                105: [6, 2], 106: [7, 4], 107: [7, 4], 108: [7, 4], 109: [7, 4], 110: [7, 4], 111: [8], 112: [8], 113: [8],
                                114: [8], 115: [8], 116: [9, 4, 3, 15], 117: [9, 4, 3, 15], 118: [9, 4, 3, 15], 119: [9, 4, 3, 15],
                                120: [9, 4, 3, 15], 121: [10, 9, 14, 5, 11],
                                122: [10, 9, 14, 5, 11], 123: [10, 9, 14, 5, 11], 124: [10, 9, 14, 5, 11], 125: [10, 9, 14, 5, 11], 126: [11, 14, 12], 127: [11, 14, 12]}
        self.controller_seonsor = {128: 52, 129: 52, 130: 52, 131: 57, 132: 57, 133: 57, 134: 57, 135: 57, 136: 62, 137: 62, 138: 62, 139: 62,
                                   140: 62, 141: 65, 142: 65, 143: 65, 144: 65, 145: 65, 146: 70, 147: 70, 148: 70, 149: 70, 150: 70, 76: 1, 77: 1,
                                   78: 1, 79: 1, 80: 1, 81: 5, 82: 5, 83: 5, 84: 5, 85: 5, 86: 11, 87: 11, 88: 11, 89: 11, 90: 11, 91: 16, 92: 16,
                                   93: 16, 94: 16, 95: 16, 96: 22, 97: 22, 98: 22, 99: 22, 100: 22, 101: 27, 102: 27, 103: 27, 104: 27, 105: 27,
                                   106: 34, 107: 34, 108: 34, 109: 34, 110: 34, 111: 39, 112: 39, 113: 39, 114: 39, 115: 39,
                                   116: 42, 117: 42, 118: 42, 119: 42, 120: 42, 121: 47, 122: 47, 123: 47, 124: 47, 125: 47, 126: 52, 127: 52}



        self.sensor_nodes =  {128: [66, 67, 68, 69, 58, 59, 60, 61], 129: [66, 67, 68, 69, 58, 59, 60, 61], 130: [66, 67, 68, 69, 58, 59, 60, 61],
                              131: [63, 64], 132: [63, 64], 133: [63, 64], 134: [63, 64], 135: [63, 64], 136: [48, 49, 50, 51], 137: [48, 49, 50, 51],
                              138: [48, 49, 50, 51], 139: [48, 49, 50, 51], 140: [48, 49, 50, 51], 146: [43, 44, 45, 46, 58, 59, 60, 61], 147: [43, 44, 45, 46, 58, 59, 60, 61],
                              148: [43, 44, 45, 46, 58, 59, 60, 61], 149: [43, 44, 45, 46, 58, 59, 60, 61], 150: [43, 44, 45, 46, 58, 59, 60, 61], 81: [17, 18, 19, 20, 21],
                              82: [17, 18, 19, 20, 21], 83: [17, 18, 19, 20, 21], 84: [17, 18, 19, 20, 21], 85: [17, 18, 19, 20, 21], 86: [2, 3, 4, 17, 18, 19, 20, 21],
                              87: [2, 3, 4, 17, 18, 19, 20, 21], 88: [2, 3, 4, 17, 18, 19, 20, 21], 89: [2, 3, 4, 17, 18, 19, 20, 21], 90: [2, 3, 4, 17, 18, 19, 20, 21],
                              91: [23, 24, 25, 26, 6, 7, 8, 9, 10, 28, 29, 30, 31, 32, 33], 92: [23, 24, 25, 26, 6, 7, 8, 9, 10, 28, 29, 30, 31, 32, 33],
                              93: [23, 24, 25, 26, 6, 7, 8, 9, 10, 28, 29, 30, 31, 32, 33], 94: [23, 24, 25, 26, 6, 7, 8, 9, 10, 28, 29, 30, 31, 32, 33],
                              95: [23, 24, 25, 26, 6, 7, 8, 9, 10, 28, 29, 30, 31, 32, 33], 96: [28, 29, 30, 31, 32, 33, 40, 41, 35, 36, 37, 38],
                              97: [28, 29, 30, 31, 32, 33, 40, 41, 35, 36, 37, 38], 98: [28, 29, 30, 31, 32, 33, 40, 41, 35, 36, 37, 38],
                              99: [28, 29, 30, 31, 32, 33, 40, 41, 35, 36, 37, 38], 100: [28, 29, 30, 31, 32, 33, 40, 41, 35, 36, 37, 38], 101: [6, 7, 8, 9, 10],
                              102: [6, 7, 8, 9, 10], 103: [6, 7, 8, 9, 10], 104: [6, 7, 8, 9, 10], 105: [6, 7, 8, 9, 10], 106: [17, 18, 19, 20, 21], 107: [17, 18, 19, 20, 21],
                              108: [17, 18, 19, 20, 21], 109: [17, 18, 19, 20, 21], 110: [17, 18, 19, 20, 21],
                              116: [17, 18, 19, 20, 21, 12, 13, 14, 15, 35, 36, 37, 38, 71, 72, 73, 74, 75],
                              117: [17, 18, 19, 20, 21, 12, 13, 14, 15, 35, 36, 37, 38, 71, 72, 73, 74, 75],
                              118: [17, 18, 19, 20, 21, 12, 13, 14, 15, 35, 36, 37, 38, 71, 72, 73, 74, 75],
                              119: [17, 18, 19, 20, 21, 12, 13, 14, 15, 35, 36, 37, 38, 71, 72, 73, 74, 75],
                              120: [17, 18, 19, 20, 21, 12, 13, 14, 15, 35, 36, 37, 38, 71, 72, 73, 74, 75],
                              121: [43, 44, 45, 46, 66, 67, 68, 69, 23, 24, 25, 26, 53, 54, 55, 56],
                              122: [43, 44, 45, 46, 66, 67, 68, 69, 23, 24, 25, 26, 53, 54, 55, 56],
                              123: [43, 44, 45, 46, 66, 67, 68, 69, 23, 24, 25, 26, 53, 54, 55, 56], 124: [43, 44, 45, 46, 66, 67, 68, 69, 23, 24, 25, 26, 53, 54, 55, 56],
                              125: [43, 44, 45, 46, 66, 67, 68, 69, 23, 24, 25, 26, 53, 54, 55, 56], 126: [66, 67, 68, 69, 58, 59, 60, 61], 127: [66, 67, 68, 69, 58, 59, 60, 61]}




    def best_node(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic,alpha):
        node_src = sim.DES_msgs[message.id]
        controller = self.controller_seonsor[node_src]
        c_ips = sim.nodes_attributes[controller][3]



        DES_dst = alloc_module[app_name][message.dst]  # returns an array with all DES process serving
        inst = message.inst
        size = message.bytes

        req_cpu = message.CPU
        req_ram = message.RAM
        req_sc = message.SC
        max_delay = message.d
        
        req_pm = message.PM
        cpu=[]
        pm=[]
        ram=[]
        ipt=[]

        delays =[]

        links = []
        nodes = []
        waiting =[]
        waiting_at_controler = 0
        f2f = []

        linkdelay = sim.msgsAd[message.id] + sim.msgsBd[message.id]

        for m in sim.queue_at_controller[controller]:
            waiting_at_controler = waiting_at_controler+ 1000/c_ips
        for key in self.sensor_nodes.keys():
            if key == node_src:

                for item in self.sensor_nodes[key]:
                    w = 0.0
                    nodes.append(item)
                    link = (node_src,item)
                    if self.controller_seonsor[node_src] != item:
                        tran = (127/125000) / 600
                        pro = 1/600000
                        f2f.append((tran+pro)*2)
                    else:
                        f2f.append(0)
                    cpu.append(sim.nodes_attributes[item][0])
                    ram.append(sim.nodes_attributes[item][1])
                    pm.append(sim.nodes_attributes[item][2])
                    ipt.append(sim.nodes_attributes[item][3])
                    if len(sim.msgs_in_queues[item]) != 0:
                      
                        for ic in sim.msgs_in_queues_ic[item]:

                            w = w + ic/sim.nodes_attributes[item][3]
                        

                    waiting.append(w)
                    links.append(link)
       

        for link in links:

            transmit = (float(message.bytes) / 125000) / (sim.topology.get_edge(link)['BW'])  # MBITS!

            propagation = float(sim.topology.get_edge(link)['PR'])
            latency_msg_link = transmit + propagation

            delays.append(latency_msg_link*2)
        
        for i in range(len(delays)):

            delays[i] = delays[i] + (inst/ float(ipt[i])) +1000/c_ips + waiting[i] + waiting_at_controler + linkdelay + f2f[i]




      
        solver = pywraplp.Solver('SolveIntegerProblem',
                                 pywraplp.Solver.CBC_MIXED_INTEGER_PROGRAMMING)
        x = []
        for i in range(len(nodes)): #x is number of nodes
            x.append(solver.IntVar(0.0, 1, 'x' + str(i)))

        constraint1 = solver.Constraint(-solver.infinity(), 1) #pick one node
        for i in range(len(x)):
            constraint1.SetCoefficient(x[i], 1)

        constraint2 = solver.Constraint(0, solver.infinity()) #doesn't exceed max allowed delay
        for i in range(len(x)):

            constraint2.SetCoefficient(x[i], float(max_delay) - delays[i])
        constraint3 = solver.Constraint(0, solver.infinity()) # satisfies the required cpu
        for i in range(len(x)):

            # print("cpu",cpu[i] - float(req_cpu))
            constraint3.SetCoefficient(x[i], cpu[i] - float(req_cpu))
        constraint4 = solver.Constraint(0, solver.infinity()) # satisfies the required ram
        for i in range(len(x)):
            # print("ram",ram[i] - float(req_ram))
            constraint4.SetCoefficient(x[i], ram[i] - float(req_ram))
        constraint5 = solver.Constraint(0, solver.infinity()) #satisfies privacy measure
        for i in range(len(x)):

            constraint5.SetCoefficient(x[i], pm[i] - float(req_pm))
        objective = solver.Objective()
        # print("msg",message.name)
        for i in range(len(x)):
         

            delay = float(max_delay) - delays[i]
           
            privacy = pm[i] - float(req_pm)
           

            coef = (delay *alpha) + (privacy*(1-alpha))
         

            objective.SetCoefficient(x[i],coef )


        #objective.SetCoefficient(x[len(x)-1], delays[len(delays)-1]) // for cloud

        objective.SetMaximization()
        result_status = solver.Solve()
        # The problem has an optimal solution.
        assert result_status == pywraplp.Solver.OPTIMAL

        # The solution looks legit (when using solvers other than
        # GLOP_LINEAR_PROGRAMMING, verifying the solution is highly recommended!).
        assert solver.VerifySolution(1e-7, True)

        # print('Number of variables =', solver.NumVariables())
        # print('Number of constraints =', solver.NumConstraints())

        # The objective value of the solution.
        # print('Optimal objective value = %d' % solver.Objective().Value())
        sid = -1
        # The value of each variable in the solution.
        variable_list = []
        counter = 0
        found = 0
        selected_node = -1
        for v in x:

            if v.solution_value() == 1:
                sid = counter
                found = 1
            counter+=1

       
        if found:
            selected_node =nodes[sid]
        elif req_sc == 1:
            selected_node =0
        
        sim.msg_to_bestnode[message.id] = selected_node


        DES_dst = alloc_module[app_name][message.dst]

        # print("GET PATH")

        # print("\tNode _ src (id_topology): %i" % node_src)
        # print("\tRequest service: %s " % message.dst)

        if "M.C" in message.name:
            
            try:
                sim.msgs_in_queues[selected_node].append(message.id)
                sim.msgs_in_queues_ic[selected_node].append(message.inst)
            except:
                print("nop")

        
        bestPath = []
        bestDES = []
        for des in DES_dst:  ## In this case, there are only one deployment
            if selected_node != -1:
                dst_node =selected_node

                path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))
                
                bestPath = [path]
                bestDES = [des]
     
        return bestPath, bestDES


    def get_path(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic):
        """
        Computes the minimun path among the source elemento of the topology and the localizations of the module

        Return the path and the identifier of the module deployed in the last element of that path
        """



        node_src = sim.msg_to_bestnode[message.id]
        if "M.D" in message.name:
           

            index = sim.msgs_in_queues[node_src].index(message.id)

            sim.msgs_in_queues[node_src].pop(index)
            sim.msgs_in_queues_ic[node_src].pop(index)

        DES_dst = alloc_module[app_name][message.dst]

        # print ("GET PATH")



        # print ("\tNode _ src (id_topology): %i" %node_src)
        # print ("\tRequest service: %s " %message.dst)

        bestPath = []
        bestDES = []

        for des in DES_dst: ## In this case, there are only one deployment
            # if dst_node == -1:
            
            dst_node = sim.DES_msgs[message.id]


           
            path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))
            # bestPath.append(path)
            # bestDES.append(des)
            bestPath = [path]
            bestDES = [des]

             



        return bestPath, bestDES

    def for_avg_delay(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic):
        """
        Computes the minimun path among the source elemento of the topology and the localizations of the module

        Return the path and the identifier of the module deployed in the last element of that path
        """
        possible = [6,7,8,9,10,12,13,14,15,16,17]
        i = random.randint(0,10)


        sim.msg_to_bestnode[message.id] = 13
        node_src = sim.DES_msgs[message.id]

        DES_dst = alloc_module[app_name][message.dst]

        # print ("GET PATH")



        # print ("\tNode _ src (id_topology): %i" %node_src)
        # print ("\tRequest service: %s " %message.dst)

        bestPath = []
        bestDES = []

        for des in DES_dst: ## In this case, there are only one deployment
           
            dst_node = 13

            
       
            path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))
           
            bestPath = [path]
            bestDES = [des]

             



        return bestPath, bestDES

    def cluster_deploy(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic):
        #sending request to the controller of the topology_src
        """
        Computes the minimun path among the source elemento of the topology and the localizations of the module

        Return the path and the identifier of the module deployed in the last element of that path
        """


        node_src = topology_src

        if (node_src in sim.population.get_src_ids()):
            sim.sources.append(node_src)


        DES_dst = alloc_module[app_name][message.dst]

        # print ("GET PATH")

        # print ("\tNode _ src (id_topology): %i" % node_src)
        # print ("\tRequest service: %s " % message.dst)

        bestPath = []
        bestDES = []

        for des in DES_dst:  ## In this case, there are only one deployment

            dst_node = self.controller_seonsor[node_src]

            path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))

            bestPath = [path]
            bestDES = [des]

        sim.queue_at_controller[dst_node].append(message.id)

        link = (node_src, self.controller_seonsor[node_src])
        transmit = (float(message.bytes) / 125000) / (sim.topology.get_edge(link)['BW'])  # MBITS!

        propagation = float(sim.topology.get_edge(link)['PR'])
        latency_msg_link = transmit + propagation
        sim.msgsAd[message.id] = latency_msg_link
        return bestPath, bestDES
    def request_reply(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic):
        #sending request to the controller of the topology_src
        """
        Computes the minimun path among the source elemento of the topology and the localizations of the module

        Return the path and the identifier of the module deployed in the last element of that path
        """

        node_src = sim.source_msgs[message.id]
        index = sim.queue_at_controller[node_src].index(message.id)
        sim.queue_at_controller[node_src].pop(index)
        if (node_src in sim.population.get_src_ids()):
            sim.sources.append(node_src)

        DES_dst = alloc_module[app_name][message.dst]

        # print ("GET PATH")

        # print ("\tNode _ src (id_topology): %i" % node_src)
        # print ("\tRequest service: %s " % message.dst)

        bestPath = []
        bestDES = []

        for des in DES_dst:  ## In this case, there are only one deployment


            dst_node = sim.DES_msgs[message.id]

            path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))

            bestPath = [path]
            bestDES = [des]
        link = (node_src,sim.DES_msgs[message.id])
        transmit = (float(message.bytes) / 125000) / (sim.topology.get_edge(link)['BW'])  # MBITS!

        propagation = float(sim.topology.get_edge(link)['PR'])
        latency_msg_link = transmit + propagation
        sim.msgsBd[message.id] = latency_msg_link

        return bestPath, bestDES


class MinPath_RoundRobin(Selection):

    def __init__(self):
        self.rr = {} #for a each type of service, we have a mod-counter

    def get_path(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic):
        """
        Computes the minimun path among the source elemento of the topology and the localizations of the module

        Return the path and the identifier of the module deployed in the last element of that path
        """
        node_src = topology_src

        DES_dst = alloc_module[app_name][message.dst] #returns an array with all DES process serving


        if message.dst not in self.rr.keys():
            self.rr[message.dst] = 0


        print ("GET PATH")
        print ("\tNode _ src (id_topology): %i" %node_src)
        print ("\tRequest service: %s " %(message.dst))
        print ("\tProcess serving that service: %s (pos ID: %i)" %(DES_dst,self.rr[message.dst]))

        bestPath = []
        bestDES = []

        for ix,des in enumerate(DES_dst):
            if message.name == "M.A":
                if self.rr[message.dst]==ix:
                    dst_node = alloc_DES[des]

                    path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))

                    bestPath = [path]
                    bestDES = [des]

                    self.rr[message.dst] = (self.rr[message.dst]+ 1) % len(DES_dst)
                    break
            else: #message.name == "M.B"

                dst_node = alloc_DES[des]

                path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))
                if message.broadcasting:
                    bestPath.append(path)
                    bestDES.append(des)
                else:
                    bestPath = [path]
                    bestDES = [des]

        return bestPath, bestDES