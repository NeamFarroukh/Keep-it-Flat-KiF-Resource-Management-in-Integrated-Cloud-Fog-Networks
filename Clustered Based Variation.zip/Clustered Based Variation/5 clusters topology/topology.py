"""

    Created on Wed Nov 22 15:03:21 2017

    @author: isaac

"""
import random

import argparse
import pandas as pd
import random
from yafs.core import Sim
from yafs.application import Application,Message

from yafs.population import *
from yafs.topology import Topology

from simpleSelection import MinimunPath
from simplePlacement import CloudPlacement
from yafs.stats import Stats
from yafs.distribution import deterministicDistribution,exponentialDistribution
from yafs.distribution import uniformDistribution
from yafs.utils import fractional_selectivity
import time
import numpy as np
from collections import defaultdict
RANDOM_SEED = 1
fog_devices = defaultdict(list)
fog_nodes_ids = defaultdict(list)

def create_application():
    # APLICATION
    df = pd.read_excel('batches/B2.xlsx')
    a = Application(name="application")


    # (S) --> (ServiceA) --> (A)
    a.set_modules([{"Sensor":{"Type":Application.TYPE_SOURCE }},
                   {"ServiceA": {"Type": Application.TYPE_MODULE}},
                   {"R": {"Type": Application.TYPE_MODULE}},
                   {"Task": {"Type": Application.TYPE_MODULE}},
                   {"Actuator": {"Type": Application.TYPE_SINK}}


                   ])
    """
    Messages among MODULES (AppEdge in iFogSim)
    """
    delays = [0.9631090703877762, 1.9244886778125894, 2.114028626755956, 3.050627909107596, 1.1140286267559558,
              1.1140286267559558, 2.050627909107596, 1.0506279091075958, 2.944769463463584, 1.944769463463584, 1.944769463463584,
              0.9447694634635839, 4.412276404590655, 3.4122764045906546, 3.4122764045906546, 2.4122764045906546, 2.4122764045906546,
              1.4122764045906546, 1.4122764045906546, 0.4122764045906546, 2.9298003635751293, 1.9298003635751293, 1.9298003635751293,
              0.9298003635751293, 3.854954760666164, 2.854954760666164, 2.854954760666164, 1.854954760666164, 1.854954760666164, 0.854954760666164,
              3.5782187543467714, 2.5782187543467714, 2.5782187543467714, 1.5782187543467714, 1.5782187543467714, 3.19938987312592, 3.19938987312592,
              3.19938987312592, 3.19938987312592, 4.971711520180968, 4.971711520180968, 3.9717115201809676, 3.9717115201809676, 2.9717115201809676,
              2.9717115201809676, 1.9717115201809676, 1.9717115201809676, 6.867161827299967, 6.867161827299967, 0.9717115201809676, 5.867161827299967,

              5.867161827299967, 4.867161827299967, 4.867161827299967, 3.8671618272999666, 3.8671618272999666, 2.8671618272999666, 2.8671618272999666,
              1.8671618272999666, 1.8671618272999666, 0.8671618272999666, 0.8671618272999666, 0.8671618272999666, 8.22748619420502, 8.22748619420502, 7.227486194205021,
              7.227486194205021, 6.227486194205021, 6.227486194205021, 5.227486194205021, 5.227486194205021, 4.227486194205021, 4.227486194205021, 4.227486194205021,
              3.227486194205021, 3.227486194205021, 2.227486194205021, 2.227486194205021, 1.2274861942050208, 1.2274861942050208, 0.2274861942050208, 9.77051590224793,
              8.77051590224793, 8.77051590224793, 8.77051590224793, 7.770515902247929, 7.770515902247929, 6.770515902247929, 6.770515902247929, 5.770515902247929,
              5.770515902247929, 5.770515902247929, 4.770515902247929, 4.770515902247929, 3.7705159022479293, 3.7705159022479293, 2.7705159022479293, 2.7705159022479293,
              1.7705159022479293, 11.278636093012771, 0.7705159022479293, 0.7705159022479293, 10.278636093012771,
              9.278636093012771, 9.278636093012771, 8.278636093012771, 8.278636093012771, 7.278636093012771, 7.278636093012771, 7.278636093012771, 6.278636093012771]
   
    msgs = []
    b =[]
    c = []
    ds = []
    # i = 150
    # j = 0
    # while i< 300:
    for i in range(99):


        
        data = df.iloc[i+1]
        instructions = data['Num of Instructions']
        bytes = data['Size']
        ram = data['Memory Request']
       
        cpu = data['CPU Request']
        sc = data['Scheduling Class']
        pm = data['Security Level']
        d = data['Delay']

   


        m_a = Message("M.A"+str(i), "Sensor", "ServiceA", instructions=1000, bytes=127)
        msgs.append(m_a)
        m_b = Message("M.B"+str(i), "ServiceA", "R")
        b.append(m_b)

        m_c = Message("M.C"+str(i), "R", "Task", instructions=instructions, bytes=bytes, RAM=ram, CPU=cpu, SC=sc, PM=pm,d=d)
        c.append(m_c)
        m_d = Message("M.D"+str(i), "Task", "Actuator")
        ds.append(m_d)



    """
    Defining which messages will be dynamically generated # the generation is controlled by Population algorithm
    """

    for i in range(99):
        a.add_source_messages(msgs[i])
        a.add_service_source("ServiceA", None, b[i])
        a.add_service_source("R", None, c[i])
        a.add_service_module("ServiceA", msgs[i], b[i], fractional_selectivity, threshold=1.0 )
        a.add_service_module("R", b[i], c[i], fractional_selectivity, threshold=1.0)
        a.add_service_module("Task", c[i], ds[i], fractional_selectivity, threshold=1.0)




    return a



def create_json_topology():
    """
       TOPOLOGY DEFINITION

       Some attributes of fog entities (nodes) are approximate
       """


    topology_json = {}
    topology_json["entity"] = []
    topology_json["link"] = []
    ## MANDATORY FIELDS
    cloud_dev    = {"id": 0, "model": "cloud","mytag":"cloud", "IPT": 317900000000000, "RAM": 40000,"COST": 3,"WATT":20.0,"CPU":50}

    df = pd.read_excel('fognodes.xlsx')

    # #for t
    # sensor_nodes = defaultdict(list)
    # controller_sensor = {}
    # controllers = {}
    # c = []
    # controller_to_nodes = defaultdict(list)
    # #

    fog_nodes = []
    fog_size = {}
    num_fogs = 0
    devices = []
    links = []
    current_fog = "Fog 1"
    prev_fog = "none"
    j = 1
    list = []
    current_controller = -1
    for i in range(len(df)):

        current_fog = df.iloc[i]['Fog ID']
        if current_fog != prev_fog:
            num_fogs += 1
            j = 1
            fog_size[current_fog[-1:]] = 1

        else:
            fog_size[current_fog[-1:]] += 1
        node_id = current_fog[-1:]

        ips = df.iloc[i]['IPS']
        cpu = df.iloc[i]['CPU']
        ram = df.iloc[i]['RAM']
        pm = df.iloc[i]['PM']

        if current_fog != prev_fog:
            list = []
            current_controller = i + 1

            node = {"id": i + 1, "model": "fogC" + str(node_id), "mytag": "fogC" + str(node_id), "IPT": ips, "RAM": ram,
                    "CPU": cpu, "PM": pm, "COST": 3, "WATT": 20.0, }
            fog_nodes_ids[int(current_fog[-1:])].append(i + 1)
            fog_nodes.append(node)
            prev_fog = current_fog
        else:

            node = {"id": i + 1, "model": "fog" + str(node_id) + "f" + str(j),
                    "mytag": "fog" + str(node_id) + "f" + str(j), "IPT": ips, "RAM": ram, "COST": 3, "WATT": 20.0,
                    "CPU": cpu, "PM": pm}
            fog_nodes_ids[int(current_fog[-1:])].append(i + 1)
            # controller_to_nodes[current_controller].append(i + 1)
            fog_nodes.append(node)
            j = j + 1
    i = 0
    counter = len(df) + 1

    for id in fog_nodes_ids:
        s = fog_nodes_ids[id][0]
        link = {"s": s, "d": 0, "BW": 10000, "PR": 0.0000033}
        links.append(link)

    n = 1
    while n <= num_fogs:
        list = []
        for j in range(3):
            list.append(counter)
            device = {"id": counter, "model": "f" + str(n) + "D" + str(j + 1), "IPT": 100 * 10 ^ 6, "RAM": 4000,
                      "COST": 3, "WATT": 40.0}

            counter = counter + 1
            devices.append(device)
        fog_devices[n] = list
        n = n + 1







    for fid in fog_nodes_ids:
        for id in fog_nodes_ids[fid]:
            i = random.randint(0, 1)
            if i == 0:
                bw = 54
            else:
                bw = 100

            d = id
            for device in fog_devices[fid]:
                link = {"s": device, "d": d, "BW": bw, "PR": 0.0000033}

                links.append(link)

    # #customized
    #
    # #devices of f2 linked to F4
    for id in fog_nodes_ids[4]:
        i = random.randint(0, 1)
        if i == 0:
            bw = 54
        else:
            bw = 100

        d = id
        for device in fog_devices[2]:
            link = {"s": device, "d": d, "BW": bw, "PR": 0.0000033}

            links.append(link)
            # if d not in c:
            #     sensor_nodes[device].append(d)

    # #devices of f3 linked to F1
    for id in fog_nodes_ids[1]:
        i = random.randint(0, 1)
        if i == 0:
            bw = 54
        else:
            bw = 100

        d = id
        for device in fog_devices[3]:
            link = {"s": device, "d": d, "BW": bw, "PR": 0.0000033}

            links.append(link)
            # if d not in c:
            #     sensor_nodes[device].append(d)
    # #devices of f3 linked to F4
    for id in fog_nodes_ids[4]:
        i = random.randint(0, 1)
        if i == 0:
            bw = 54
        else:
            bw = 100

        d = id
        for device in fog_devices[3]:
            link = {"s": device, "d": d, "BW": bw, "PR": 0.0000033}

            links.append(link)
            # if d not in c:
            #     sensor_nodes[device].append(d)
    # #devices of f4 linked to F5
    for id in fog_nodes_ids[5]:
        i = random.randint(0, 1)
        if i == 0:
            bw = 54
        else:
            bw = 100

        d = id
        for device in fog_devices[4]:
            link = {"s": device, "d": d, "BW": bw, "PR": 0.0000033}

            links.append(link)
            # if d not in c:
            #     sensor_nodes[device].append(d)
    # #devices of f4 linked to F2
    for id in fog_nodes_ids[2]:
        i = random.randint(0, 1)
        if i == 0:
            bw = 54
        else:
            bw = 100

        d = id
        for device in fog_devices[4]:
            link = {"s": device, "d": d, "BW": bw, "PR": 0.0000033}
            links.append(link)
            # if d not in c:
            #     sensor_nodes[device].append(d)




    topology_json["entity"].append(cloud_dev)
    for i in range(len(fog_nodes)):

        topology_json["entity"].append(fog_nodes[i])



    for d in devices:

        topology_json["entity"].append(d)



    for link in links:

        topology_json["link"].append(link)


    return topology_json



# @profile
def main(simulated_time):

    random.seed(RANDOM_SEED)
    np.random.seed(RANDOM_SEED)

    """
    TOPOLOGY from a json
    """
    t = Topology()
    t_json = create_json_topology()
    t.load(t_json)
    t.write("network.gexf")

    """
    APPLICATION
    """
    app = create_application()

    #app2 =  create_application2(random.uniform(0,1),random.uniform(0,1),15000,127,1,random.uniform(0,1),d)


    """
    POPULATION algorithm
    """
    #In ifogsim, during the creation of the application, the Sensors are assigned to the topology, in this case no. As mentioned, YAFS differentiates the adaptive sensors and their topological assignment.
    #In their case, the use a statical assignment.


    pop = Statical("Statical")


    #For each type of sink modules we set a deployment on some type of devices
    #A control sink consists on:
    #  args:
    #     model (str): identifies the device or devices where the sink is linked
    #     number (int): quantity of sinks linked in each device
    #     module (str): identifies the module from the app who receives the messages
    dDistribution = exponentialDistribution(name="exponential", lambd=1.5)


    for i in range(3):
        for j in range(5):

            pop.set_sink_control({"model": "f"+str(j+1)+"D"+str(i+1), "number": 1, "module": app.get_sink_modules()})

    for k in range(3):
        for j in range(5):
            for i in range(99):
                pop.set_src_control({"model": "f"+str(j+1)+"D"+str(k+1), "number": 1, "message": app.get_message("M.A" + str(i)),
                                     "distribution": dDistribution})


    """--
    SELECTOR algorithm
    """
    #Their "selector" is actually the shortest way, there is not type of orchestration algorithm.
    #This implementation is already created in selector.class,called: First_ShortestPath
    selectorPath = MinimunPath()


    """
    PLACEMENT algorithm
    
    """
    placement = CloudPlacement("OnCloud", activation_dist=dDistribution)  # it defines the deployed rules: module-device
    placement.scaleService({"ServiceA": 1, "Task": 1, "R": 1})

        #placements.append(placement)
    """
    SIMULATION ENGINE
    """
    stop_time = simulated_time
    s = Sim(t, default_results_path="Results5")
    s.deploy_app(app, placement, pop, selectorPath)
    # s.deploy_app(apps[1], placement, pops[1], selectorPath)
  
    s.run(stop_time,0.9 ,show_progress_monitor=False)


    # s.draw_allocated_topology() # for debugging

if __name__ == '__main__':
    import logging.config
    import os

    # logging.config.fileConfig(os.getcwd()+'/logging.ini')

    start_time = time.time()
    main(simulated_time=50)

    print("\n--- %s seconds ---" % (time.time() - start_time))

    ### Finally, you can analyse the results:
    # print "-"*20
    # print "Results:"
    # print "-" * 20
    # m = Stats(defaultPath="Results") #Same name of the results
    # time_loops = [["M.A", "M.B"]]
    # m.showResults2(1000, time_loops=time_loops)
    # print "\t- Network saturation -"
    # print "\t\tAverage waiting messages : %i" % m.average_messages_not_transmitted()
    # print "\t\tPeak of waiting messages : %i" % m.peak_messages_not_transmitted()PartitionILPPlacement
    # print "\t\tTOTAL messages not transmitted: %i" % m.messages_not_transmitted()
