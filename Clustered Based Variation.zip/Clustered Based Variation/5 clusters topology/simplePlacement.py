"""
    This type of algorithm have two obligatory functions:

        *initial_allocation*: invoked at the start of the simulation

        *run* invoked according to the assigned temporal distribution.

"""
from __future__ import print_function
from ortools.linear_solver import pywraplp

import random
import decimal
from yafs.placement import Placement
from yafs.application import Application,Message
class CloudPlacement(Placement):
        """
        This implementation locates the services of the application in the cheapest cloud regardless of where the sources or sinks are located.

        It only runs once, in the initialization.

        """


        # def __init__(self):
        #
        #     super(CloudPlacement, self).__init__(self)
        def initial_allocation(self, sim, app_name):
            self.app = app_name
           
            

            controller_seonsor = {3:(4,6),5:(1,6,7,8)}
            controller_controller = {3:(5),5:(3)}
            sensor_nodes = {1:[4,6,7],8:[4,6,7]}
            controller_nodes = {5:(6,7),3:(4)}

          

        def run(self, sim):



            app = sim.apps[self.app]
            services = app.services
            id_cluster = sim.topology.find_IDs({"id": 3})
            controllers_id = [5,3]
            for rep in range(0, self.scaleServices["ServiceA"]):
                sim.deploy_module(self.app, "ServiceA", services["ServiceA"],id_cluster)
            id_cluster = sim.topology.find_IDs({"id": 7})

            for rep in range(0, self.scaleServices["Task"]):

                sim.deploy_module(self.app, "Task", services["Task"], id_cluster)

                    # #

            id_cluster = sim.topology.find_IDs({"id": 1})
            # ids.append(id_cluster)
            id_cluster = sim.topology.find_IDs({"id":1})
            # ids.append(id_cluster)
            ids  = [1,8,9]
            for rep in range(0, self.scaleServices["R"]):

                sim.deploy_module(self.app, "R",  services["R"],id_cluster)




                    #end function




