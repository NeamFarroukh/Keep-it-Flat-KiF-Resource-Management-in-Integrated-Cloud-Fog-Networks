from __future__ import print_function
from ortools.linear_solver import pywraplp
import random
from yafs.selection import Selection
import networkx as nx
from collections import defaultdict

class MinimunPath(Selection):


    def __init__(self):
        self.rr = {}  # for a each type of service, we have a mod-counter
        self.messages_affected = []
      


        #for my topology
        self.reach_clusters = {32: [2, 4], 33: [3, 1, 4], 34: [3, 1, 4], 35: [3, 1, 4], 36: [4, 5, 2],
                               37: [4, 5, 2], 38: [4, 5, 2], 39: [5], 40: [5], 41: [5], 27: [1], 28: [1], 29: [1], 30: [2, 4], 31: [2, 4]}
        self.controller_seonsor = {27: 1, 28: 1, 29: 1, 30: 1, 31: 1, 32: 5, 33: 5, 34: 5, 35: 5, 36: 5, 37: 11, 38: 11,
                                  39: 11, 40: 11, 41: 11, 42: 16, 43: 16, 44: 16, 45: 16, 46: 16, 47: 22, 48: 22,
                                  49: 22, 50: 22, 51: 22}
        self.sensor_nodes = {32: [6, 7, 8, 9, 10, 17, 18, 19, 20, 21],
                             33: [12, 13, 14, 15, 2, 3, 4, 17, 18, 19, 20, 21],
                             34: [12, 13, 14, 15, 2, 3, 4, 17, 18, 19, 20, 21],
                             35: [12, 13, 14, 15, 2, 3, 4, 17, 18, 19, 20, 21],
                             36: [17, 18, 19, 20, 21, 23, 24, 25, 26, 6, 7, 8, 9, 10],
                             37: [17, 18, 19, 20, 21, 23, 24, 25, 26, 6, 7, 8, 9, 10],
                             38: [17, 18, 19, 20, 21, 23, 24, 25, 26, 6, 7, 8, 9, 10], 39: [23, 24, 25, 26],
                             40: [23, 24, 25, 26], 41: [23, 24, 25, 26], 27: [2, 3, 4], 28: [2, 3, 4], 29: [2, 3, 4],
                             30: [6, 7, 8, 9, 10, 17, 18, 19, 20, 21], 31: [6, 7, 8, 9, 10, 17, 18, 19, 20, 21]}
        self.clusters_avgs = {1: [5184000.0, 2528890.0, 833000.0, 0.43372386030203053],
                              2: [1558166.6666666667, 344837.3333333333, 3540666.6666666665, 0.5316469092643333],
                              3: [1721800.0, 413292.8, 4230400.0, 0.6942051197056001], 4: [3861500.0, 532750.6666666666, 2331666.6666666665, 0.7789872655232192],
                              5: [3633800.0, 638980.8, 2732000.0, 0.8277379679732], 6: [3943571.4285714286, 1599637.7142857143, 2056000.0, 0.6595830577078571],
                              7: [1695600.0, 236553.6, 2376400.0, 0.8821122381305069], 8: [2660920.0, 68123.51999999999, 771680.0, 0.6352842737584192],
                              9: [3660000.0, 815720.0, 4586000.0, 0.6899640651913652], 10: [6226400.0, 3213832.0, 620400.0, 0.5539803062926],
                              11: [1721800.0, 413292.8, 4230400.0, 0.6942051197056001], 12: [1695600.0, 236553.6, 2376400.0, 0.8821122381305069],
                              13: [2203000.0, 34154.666666666664, 384000.0, 0.47396855950166666], 14: [3660000.0, 815720.0, 4586000.0, 0.6899640651913652],
                              15: [1558166.6666666667, 344837.3333333333, 3540666.6666666665, 0.5316469092643333],
                              16: [3882361.1111111115, 1907066.2222222222, 2812111.1111111105, 0.47245946434007585],
                              17: [3861500.0, 532750.6666666666, 2331666.6666666665, 0.7789872655232192],
                              18: [6226400.0, 3213832.0, 620400.0, 0.5539803062926],
                              19: [3633800.0, 638980.8, 2732000.0, 0.8277379679732], 20: [3660000.0, 815720.0, 4586000.0, 0.6899640651913652]}
        self.cluster_nodes = {1: [1, 2, 3, 4], 2: [5, 6, 7, 8, 9, 10], 3: [11, 12, 13, 14, 15],
                               4: [16, 17, 18, 19, 20, 21], 5: [22, 23, 24, 25, 26], 6: [27, 28, 29, 30, 31, 32, 33],
                               7: [34, 35, 36, 37, 38], 8: [39, 40, 41], 9: [42, 43, 44, 45, 46], 10: [47, 48, 49, 50, 51],
                               11: [52, 53, 54, 55, 56], 12: [57, 58, 59, 60, 61], 13: [62, 63, 64], 14: [65, 66, 67, 68, 69],
                               15: [70, 71, 72, 73, 74, 75], 16: [76, 77, 78, 79], 17: [80, 81, 82, 83, 84, 85],
                               18: [86, 87, 88, 89, 90], 19: [91, 92, 93, 94, 95], 20: [96, 97, 98, 99, 100]}
     

    def get_cluster(self,cpu,ram,ic,pm,max_delay,src):
        num = len(self.reach_clusters[src])
        pms = []
        rams = []
        cpus  = []
        ips = []
        ids = []
        for cluster in self.reach_clusters[src]:
            ids.append(cluster)
            cpus.append(self.clusters_avgs[cluster][0])
            rams.append(self.clusters_avgs[cluster][1])
            ips.append(self.clusters_avgs[cluster][2])
            pms.append(self.clusters_avgs[cluster][3])
        solver = pywraplp.Solver('SolveIntegerProblem',
                                 pywraplp.Solver.CBC_MIXED_INTEGER_PROGRAMMING)
        x = []
        for i in range(num):  # x is number of nodes
            x.append(solver.IntVar(0.0, 1, 'x' + str(i)))
        constraint1 = solver.Constraint(0, solver.infinity())  # satisfies pm
        for i in range(len(x)):
            constraint1.SetCoefficient(x[i], pms[i] - float(pm))
        constraint2 = solver.Constraint(0, solver.infinity())  # satisfies cpu
        for i in range(len(x)):
            constraint2.SetCoefficient(x[i], cpus[i] - float(cpu))
        constraint3 = solver.Constraint(0, solver.infinity())  # satisfies pm
        for i in range(len(x)):
            constraint3.SetCoefficient(x[i], rams[i] - float(ram))
        constraint4 = solver.Constraint(0, solver.infinity())  # satisfies pm
        for i in range(len(x)):
            constraint4.SetCoefficient(x[i], float(max_delay)-(ic/ips[i]))
        objective = solver.Objective()
        constraint5 = solver.Constraint(-solver.infinity(), 1)  # pick one node
        for i in range(len(x)):
            constraint5.SetCoefficient(x[i], 1)
 
        for i in range(len(x)):

            coef = ( pms[i] - pm)*0.1 + (float(max_delay)-(ic/ips[i]))*0.9


            objective.SetCoefficient(x[i], coef)

        # objective.SetCoefficient(x[len(x)-1], delays[len(delays)-1]) // for cloud

        objective.SetMaximization()
        result_status = solver.Solve()
        # The problem has an optimal solution.
        assert result_status == pywraplp.Solver.OPTIMAL

        # The solution looks legit (when using solvers other than
        # GLOP_LINEAR_PROGRAMMING, verifying the solution is highly recommended!).
        assert solver.VerifySolution(1e-7, True)
        counter = 0
        selected_cluster_index = -1
        for variable in x:
            if variable.solution_value() == 1:
                selected_cluster_index = counter

            counter += 1
          
        if selected_cluster_index != -1:
            return ids[selected_cluster_index]
        else:
            return -1



    def best_node(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic,alpha):
        node_src = sim.DES_msgs[message.id]




        DES_dst = alloc_module[app_name][message.dst]  # returns an array with all DES process serving
        inst = message.inst
        size = message.bytes

        req_cpu = message.CPU
        req_ram = message.RAM
        req_sc = message.SC
        max_delay = message.d
        
        req_pm = message.PM
        cluster = self.get_cluster( req_cpu, req_ram, inst, req_pm, max_delay, node_src)

        if cluster != -1:
            controller = self.cluster_nodes[cluster][0]
            c_ips = sim.nodes_attributes[controller][3]
            cpu=[]
            pm=[]
            ram=[]
            ipt=[]

            delays =[]

            links = []

            waiting =[]
            waiting_at_controler = 0
            f2f = []

            linkdelay = sim.msgsAd[message.id] + sim.msgsBd[message.id]

            for m in sim.queue_at_controller[controller]:
                waiting_at_controler = waiting_at_controler + 1000/c_ips
            nodes = self.cluster_nodes[cluster]
            i = 1

            while i < len(nodes):
                link = (node_src, nodes[i])
                w = 0.0
                cpu.append(sim.nodes_attributes[nodes[i]][0])
                ram.append(sim.nodes_attributes[nodes[i]][1])
                pm.append(sim.nodes_attributes[nodes[i]][2])
                ipt.append(sim.nodes_attributes[nodes[i]][3])
                if len(sim.msgs_in_queues[nodes[i]]) != 0:
                   
                    for ic in sim.msgs_in_queues_ic[nodes[i]]:
                        w = w + ic / sim.nodes_attributes[nodes[i]][3]
                     

                waiting.append(w)
                links.append(link)
                i=i+1

        

            for link in links:

                transmit = (float(message.bytes) / 125000) / (sim.topology.get_edge(link)['BW'])  # MBITS!

                propagation = float(sim.topology.get_edge(link)['PR'])
                latency_msg_link = transmit + propagation

                delays.append(latency_msg_link*2)
       
            for i in range(len(delays)):

                delays[i] = delays[i] + (inst/ float(ipt[i])) +1000/c_ips + waiting[i] + waiting_at_controler + linkdelay




            solver = pywraplp.Solver('SolveIntegerProblem',
                                     pywraplp.Solver.CBC_MIXED_INTEGER_PROGRAMMING)
            x = []
            for i in range(len(nodes)-1): #x is number of nodes
                x.append(solver.IntVar(0.0, 1, 'x' + str(i)))

            constraint1 = solver.Constraint(-solver.infinity(), 1) #pick one node
            for i in range(len(x)):
                constraint1.SetCoefficient(x[i], 1)

            constraint2 = solver.Constraint(0, solver.infinity()) #doesn't exceed max allowed delay
            for i in range(len(x)):

                constraint2.SetCoefficient(x[i], float(max_delay) - delays[i])
            constraint3 = solver.Constraint(0, solver.infinity()) # satisfies the required cpu
            for i in range(len(x)):

                # print("cpu",cpu[i] - float(req_cpu))
                constraint3.SetCoefficient(x[i], cpu[i] - float(req_cpu))
            constraint4 = solver.Constraint(0, solver.infinity()) # satisfies the required ram
            for i in range(len(x)):
                # print("ram",ram[i] - float(req_ram))
                constraint4.SetCoefficient(x[i], ram[i] - float(req_ram))
            constraint5 = solver.Constraint(0, solver.infinity()) #satisfies privacy measure
            for i in range(len(x)):

                constraint5.SetCoefficient(x[i], pm[i] - float(req_pm))
            objective = solver.Objective()
          
            for i in range(len(x)):
             

                delay = float(max_delay) - delays[i]
            
                privacy = pm[i] - float(req_pm)
              

                coef = (delay *alpha) + (privacy*(1-alpha))
                

                objective.SetCoefficient(x[i],coef )


            #objective.SetCoefficient(x[len(x)-1], delays[len(delays)-1]) // for cloud

            objective.SetMaximization()
            result_status = solver.Solve()
            # The problem has an optimal solution.
            assert result_status == pywraplp.Solver.OPTIMAL

            # The solution looks legit (when using solvers other than
            # GLOP_LINEAR_PROGRAMMING, verifying the solution is highly recommended!).
            assert solver.VerifySolution(1e-7, True)

            # print('Number of variables =', solver.NumVariables())
            # print('Number of constraints =', solver.NumConstraints())

            # The objective value of the solution.
            # print('Optimal objective value = %d' % solver.Objective().Value())
            sid = -1
            # The value of each variable in the solution.
            variable_list = []
            counter = 0
            found = 0
            selected_node = 0
            for v in x:

                if v.solution_value() == 1:
                    sid = counter
                    found = 1
                counter+=1

  
            if found:
                selected_node =nodes[sid]
            elif req_sc == 1:
                selected_node =0
        
            sim.msg_to_bestnode[message.id] = selected_node


            DES_dst = alloc_module[app_name][message.dst]

        # print("GET PATH")

        # print("\tNode _ src (id_topology): %i" % node_src)
        # print("\tRequest service: %s " % message.dst)

            if "M.C" in message.name:
                
                try:
                    sim.msgs_in_queues[selected_node].append(message.id)
                    sim.msgs_in_queues_ic[selected_node].append(message.inst)
                except:
                    print("nop")

        
            bestPath = []
            bestDES = []
            for des in DES_dst:  ## In this case, there are only one deployment
                if selected_node != -1:
                    dst_node =selected_node

                    path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))

                    bestPath = [path]
                    bestDES = [des]
     
            return bestPath, bestDES
        else:

            bestPath = []
            bestDES = []
            return bestPath, bestDES



    def get_path(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic):
        """
        Computes the minimun path among the source elemento of the topology and the localizations of the module

        Return the path and the identifier of the module deployed in the last element of that path
        """



        node_src = sim.msg_to_bestnode[message.id]
        if "M.D" in message.name:
            

            index = sim.msgs_in_queues[node_src].index(message.id)

            sim.msgs_in_queues[node_src].pop(index)
            sim.msgs_in_queues_ic[node_src].pop(index)

        DES_dst = alloc_module[app_name][message.dst]

        # print ("GET PATH")



        # print ("\tNode _ src (id_topology): %i" %node_src)
        # print ("\tRequest service: %s " %message.dst)

        bestPath = []
        bestDES = []

        for des in DES_dst: ## In this case, there are only one deployment
            # if dst_node == -1:
            
            dst_node = sim.DES_msgs[message.id]


           
            path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))
            # bestPath.append(path)
            # bestDES.append(des)
            bestPath = [path]
            bestDES = [des]

             


            



        return bestPath, bestDES

    def for_avg_delay(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic):
        """
        Computes the minimun path among the source elemento of the topology and the localizations of the module

        Return the path and the identifier of the module deployed in the last element of that path
        """
        possible = [6,7,8,9,10,12,13,14,15,16,17]
        i = random.randint(0,10)


        sim.msg_to_bestnode[message.id] = 13
        node_src = sim.DES_msgs[message.id]

        DES_dst = alloc_module[app_name][message.dst]

        # print ("GET PATH")



        # print ("\tNode _ src (id_topology): %i" %node_src)
        # print ("\tRequest service: %s " %message.dst)

        bestPath = []
        bestDES = []

        for des in DES_dst: ## In this case, there are only one deployment
           
            dst_node = 13

            
            path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))
           
            bestPath = [path]
            bestDES = [des]

             



        return bestPath, bestDES

    def cluster_deploy(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic):
        #sending request to the controller of the topology_src
        """
        Computes the minimun path among the source elemento of the topology and the localizations of the module

        Return the path and the identifier of the module deployed in the last element of that path
        """


        node_src = topology_src

        if (node_src in sim.population.get_src_ids()):
            sim.sources.append(node_src)


        DES_dst = alloc_module[app_name][message.dst]

        # print ("GET PATH")

        # print ("\tNode _ src (id_topology): %i" % node_src)
        # print ("\tRequest service: %s " % message.dst)

        bestPath = []
        bestDES = []

        for des in DES_dst:  ## In this case, there are only one deployment

            dst_node = self.controller_seonsor[node_src]

            path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))

            bestPath = [path]
            bestDES = [des]

        sim.queue_at_controller[dst_node].append(message.id)

        link = (node_src, self.controller_seonsor[node_src])
        transmit = (float(message.bytes) / 125000) / (sim.topology.get_edge(link)['BW'])  # MBITS!

        propagation = float(sim.topology.get_edge(link)['PR'])
        latency_msg_link = transmit + propagation
        sim.msgsAd[message.id] = latency_msg_link
        return bestPath, bestDES
    def request_reply(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic):
        #sending request to the controller of the topology_src
        """
        Computes the minimun path among the source elemento of the topology and the localizations of the module

        Return the path and the identifier of the module deployed in the last element of that path
        """

        node_src = sim.source_msgs[message.id]
        index = sim.queue_at_controller[node_src].index(message.id)
        sim.queue_at_controller[node_src].pop(index)
        if (node_src in sim.population.get_src_ids()):
            sim.sources.append(node_src)

        DES_dst = alloc_module[app_name][message.dst]

        # print ("GET PATH")

        # print ("\tNode _ src (id_topology): %i" % node_src)
        # print ("\tRequest service: %s " % message.dst)

        bestPath = []
        bestDES = []

        for des in DES_dst:  ## In this case, there are only one deployment


            dst_node = sim.DES_msgs[message.id]

            path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))

            bestPath = [path]
            bestDES = [des]
        link = (node_src,sim.DES_msgs[message.id])
        transmit = (float(message.bytes) / 125000) / (sim.topology.get_edge(link)['BW'])  # MBITS!

        propagation = float(sim.topology.get_edge(link)['PR'])
        latency_msg_link = transmit + propagation
        sim.msgsBd[message.id] = latency_msg_link

        return bestPath, bestDES


class MinPath_RoundRobin(Selection):

    def __init__(self):
        self.rr = {} #for a each type of service, we have a mod-counter

    def get_path(self, sim, app_name, message, topology_src, alloc_DES, alloc_module, traffic):
        """
        Computes the minimun path among the source elemento of the topology and the localizations of the module

        Return the path and the identifier of the module deployed in the last element of that path
        """
        node_src = topology_src

        DES_dst = alloc_module[app_name][message.dst] #returns an array with all DES process serving


        if message.dst not in self.rr.keys():
            self.rr[message.dst] = 0


        print ("GET PATH")
        print ("\tNode _ src (id_topology): %i" %node_src)
        print ("\tRequest service: %s " %(message.dst))
        print ("\tProcess serving that service: %s (pos ID: %i)" %(DES_dst,self.rr[message.dst]))

        bestPath = []
        bestDES = []

        for ix,des in enumerate(DES_dst):
            if message.name == "M.A":
                if self.rr[message.dst]==ix:
                    dst_node = alloc_DES[des]

                    path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))

                    bestPath = [path]
                    bestDES = [des]

                    self.rr[message.dst] = (self.rr[message.dst]+ 1) % len(DES_dst)
                    break
            else: #message.name == "M.B"

                dst_node = alloc_DES[des]

                path = list(nx.shortest_path(sim.topology.G, source=node_src, target=dst_node))
                if message.broadcasting:
                    bestPath.append(path)
                    bestDES.append(des)
                else:
                    bestPath = [path]
                    bestDES = [des]

        return bestPath, bestDES