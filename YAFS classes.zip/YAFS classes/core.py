# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
"""
This module unifies the event-discrete simulation environment with the rest of modules: placement, topology, selection, population, utils and metrics.

"""


import logging
import random
import copy
from collections import defaultdict

import simpy
from tqdm import tqdm
from yafs.population import *
from yafs.topology import Topology
from yafs.application import Application
from yafs.metrics import Metrics
from yafs.distribution import *
from yafs import utils
import threading
import numpy as np

EVENT_UP_ENTITY = "node_up"
EVENT_DOWN_ENTITY = "node_down"

NETWORK_LIMIT = 100000000

class Sim:
    """

    This class contains the cloud event-discrete simulation environment and it controls the structure variables.


    Args:
       topology (object) - the associate (:mod:`Topology`) of the environment. There is only one.

    Kwargs:
       name_register (str): database file name where are registered the events.

       purge_register (boolean): True - clean the database

       logger (logger) - logger


    **Main variables to coordinate with algorithm:**


    """
    NODE_METRIC = "COMP_M"
    SOURCE_METRIC = "SRC_M"
    FORWARD_METRIC = "FWD_M"
    SINK_METRIC = "SINK_M"
    LINK_METRIC = "LINK"


    def __init__(self,topology, name_register='events_log.json', link_register='links_log.json', redis=None, purge_register=True, logger=None, default_results_path=None):

        self.env = simpy.Environment()
        """
        the discrete-event simulator (aka DES)
        """
        self.id_node = -1
        self.last= -1
        self.source = 0
        self.busy_module = {}
        self.counter = 0
        self.__idProcess = -1
        self.queue = {}
        self.rejected = 0
        self.msgstocontroller =  defaultdict(list)
        self.timestamps = defaultdict(list)
        self.alpha = -1
        # an unique indentifier for each process in the DES
        self.alloc_msgs = {}
        self.source_msgs={}
        self.__idMessage = 0
        self.lasttime = 0
        self.queue_at_controller = defaultdict(list)
        self.msgsAd = {}
        self.msgsBd = {}
        # an unique indentifier for each message
        self.app = None
        self.done = []
        self.network_ctrl_pipe = simpy.Store(self.env)
        self.network_pump = 0
        self.msg_to_bestnode ={}
        # a shared resource that control the exchange of messagess in the topology
        self.sources = []
        # self.satisfied = 0
        self.DES_msgs = {}
        self.satisfied = 0
        self.stop = False
        self.newpop = None
        self.msgs_in_queues = defaultdict(list)
        self.msgs_in_queues_ic = defaultdict(list)

		#new 

        """
        Any algorithm can stop internally the simulation putting these value to True. By default is False.
        """

        self.topology = topology
        self.logger = logger or logging.getLogger(__name__)
        self.apps = {}

        self.until = 0 #End time simulation
        #self.db = TinyDB(name_register)
        self.metrics = Metrics(default_results_path=default_results_path)

        self.unreachabled_links = 0

        "Contains the database where all events are recorded"



        """
        Clear the database
        """

        self.entity_metrics = self.__init_metrics()
        """
        Current consumed metrics of each element topology: Nodes & Edges
        """
        self.placement = " "
        dDistribution = deterministicDistribution(name="deterministic", time=1)
        self.population =  None
        self.placement_policy = {}
        # for app.name the placement algorithm

        self.population_policy = {}
        # for app.name the population algorithm

        # for app.nmae
        # self.process_topology = {}

        self.des_process_running = {}
        # Start/stop flag for each pure source
        # key: id.source.process
        # value: Boolean

        self.des_control_process = {}
        # key: app.name
        # value: des process

        self.alloc_source = {}
        """
        Relationship of pure source with topology entity

        id.source.process -> value: dict("id","app","module")

          .. code-block:: python

            alloc_source[34] = {"id":id_node,"app":app_name,"module":source module}

        """

        self.consumer_pipes = {}
        # Queues for each message
        # App+module+idDES -> pipe

        self.alloc_module = {}
        """
        Represents the deployment of a module in a DES PROCESS each DES has a one topology.node.id (see alloc_des var.)

        It used for (:mod:`Placement`) class interaction.

        A dictionary where the key is an app.name and value is a dictionary with key is a module and value an array of id DES process

        .. code-block:: python

            {"EGG_GAME":{"Controller":[1,3,4],"Client":[4]}}

        """


        self.alloc_DES = {}
        """
        The relationship between DES process and topology.node.id

        It is necessary to identify the message.source (topology.node)
        1.N. DES process -> 1. topology.node

        """

        self.selector_path = {}
        # Store for each app.name the selection policy
        # app.name -> Selector

        self.last_busy_time = {}  # must be updated with up/down nodes
        # This variable control the lag of each busy network links. It avoids the generation of a DES-process for each link
        # edge -> last_use_channel (float) = Simulation time
        self.nodes_attributes = defaultdict(list)
        all_info = self.topology.get_info()
        for i in range(len(all_info)):
            if "fog" in all_info[i]['model']:
                key = all_info[i]['id']
                self.nodes_attributes[key].append(all_info[i]['CPU'])
                self.nodes_attributes[key].append(all_info[i]['RAM'])
                self.nodes_attributes[key].append(all_info[i]['PM'])
                self.nodes_attributes[key].append(all_info[i]['IPT'])

        #
        #
       


    # self.__send_message(app_name, message, idDES, self.SOURCE_METRIC)
    def __send_message(self, app_name, message, idDES, type):
        """
        Any exchange of messages is done with this function. It is responsible for updating the metrics

        Args:
            app_name (string)º

            message: (:mod:`Message`)

        Kwargs:
            id_src (int) identifier of a pure source module
        """
        #TODO IMPROVE asignation of topo = alloc_DES(IdDES) , It has to move to the get_path process
        try:
            
        

            if "M.C" in message.name:
               
                paths, DES_dst =self.selector_path[app_name].best_node(self, app_name, message, self.alloc_DES[idDES],self.alloc_DES, self.alloc_module, self.last_busy_time,self.alpha)
            elif "M.A" in message.name:

               
                self.sources.append(self.alloc_DES[idDES])


                paths, DES_dst = self.selector_path[app_name].cluster_deploy(self, app_name, message, self.alloc_DES[idDES],self.alloc_DES, self.alloc_module,self.last_busy_time)

            
                self.DES_msgs[message.id] = self.alloc_DES[idDES]


                self.msgstocontroller[paths[0][1]].append(message.id)
                self.source_msgs[message.id] = paths[0][1]



            elif "M.B" in message.name:

                paths, DES_dst = self.selector_path[app_name].request_reply(self, app_name, message,
                                                                            self.alloc_DES[idDES], self.alloc_DES,
                                                                            self.alloc_module, self.last_busy_time)



            else:

               

                paths, DES_dst = self.selector_path[app_name].get_path(self, app_name, message,self.alloc_DES[idDES], self.alloc_DES,self.alloc_module, self.last_busy_time)

            if DES_dst == [None] or DES_dst==[[]]:

                self.logger.warning(
                    "(#DES:%i)\t--- Unreacheable DST:\t%s: PATH:%s " % (idDES, message.name, paths))
            else:
                if "M.A" in message.name:
                    self.logger.debug(
                        "(#DES:%i)\t--- SENDING Message:\t%s: PATH:%s  DES:%s THEID: %s" % (idDES, message.name, paths, DES_dst,message.id))
                else:
                    self.logger.debug("(#DES:%i)\t--- SENDING Message:\t%s: PATH:%s  DES:%s" % (idDES, message.name,paths,DES_dst))

               
                for idx,path in enumerate(paths):

                    msg = copy.copy(message)
                    msg.path = copy.copy(path)
                    msg.app_name = app_name
                    msg.idDES = DES_dst[idx]
                    if len(path) > 2:
                         self.alloc_msgs[msg.id] = path[2]
                    else:

                        self.alloc_msgs[msg.id] = path[1]




                   

                    self.network_ctrl_pipe.put(msg)
            # self.placement.run(self)
        except KeyError:

            self.logger.warning("(#DES:%i)\t--- Unreacheable DST:\t%s " % (idDES, message.name))

    def __network_process(self):
        """
        This is an internal DES-process who manages the latency of messages sent in the network.
        Performs the simulation of packages within the path between src and dst entities decided by the selection algorithm.
        In this way, the message has a transmission latency.
        """
        edges = self.topology.get_edges().keys()

        self.last_busy_time = {} # dict(zip(edges, [0.0] * len(edges)))
        while not self.stop:
            message = yield self.network_ctrl_pipe.get()


            try:

                 self.queue[message.path[0]] +=1
            except:
                self.queue[message.path[0]] = 1
          

            # If same SRC and PATH or the message has achieved the penultimate node to reach the dst
            if not message.path or message.path[-1] == message.dst_int or len(message.path)==1:

                pipe_id = "%s%s%i" %(message.app_name,message.dst,message.idDES)  # app_name + module_name (dst) + idDES
                # Timestamp reception message in the module

                # self.busy_module[message.path[0]] = 1
                # The message is sent to the module.pipe
                self.consumer_pipes[pipe_id].put(message)
            else:

                # The message is sent at first time or it sent more times.
                if message.dst_int < 0:
                    src_int = message.path[0]
                    message.dst_int = message.path[1]
                else:

                    src_int = message.dst_int
                    message.dst_int = message.path[message.path.index(message.dst_int) + 1]
                # arista set by (src_int,message.dst_int)

                link = (src_int, message.dst_int)


                # Links in the topology are bidirectional: (a,b) == (b,a)
                try:
                    last_used = self.last_busy_time[link]
                except KeyError:

                    last_used = 0.0
                    # self.last_busy_time[link] = last_used

                    #link = (message.dst_int, src_int)
                    #last_used = self.last_busy_time[link]
                """
                Computing message latency
                """
               
                size_bits = message.bytes
               
                try:
                   # transmit = size_bits / (self.topology.get_edge(link)[Topology.LINK_BW] * 1000000.0)  # MBITS!
                    transmit = (float(message.bytes)/125000) / (self.topology.get_edge(link)[Topology.LINK_BW] )  # MBITS!
                   
                    propagation = float(self.topology.get_edge(link)[Topology.LINK_PR])
                   
                    latency_msg_link = transmit + propagation
                   
                    # update link metrics
                    self.metrics.insert_link(
                        {"id":message.id,"type": message.id,"src":message.name,"dst":link[1],"app":message.app_name,"latency":latency_msg_link,"message": message.name,"ctime":self.env.now,"size":message.bytes,"buffer":self.network_pump})#"path":message.path})
                  
                    if "M.B" in message.name:
                        message.timestamp_rec= self.timestamps[message.id][0] + latency_msg_link

                    elif "M.C" in message.name:
                        message.timestamp_rec = self.timestamps[message.id][1] + latency_msg_link
                    elif "M.D" in message.name:
                        message.timestamp_rec = self.timestamps[message.id][2] + latency_msg_link
                    else:
                        message.timestamp_rec = self.env.now + latency_msg_link

                    # We compute the future latency considering the current utilization of the link
                    if last_used < self.env.now:
                        shift_time = 0.0
                        last_used = latency_msg_link + self.env.now  # future arrival time
                    else:
                        shift_time = last_used - self.env.now
                        last_used = self.env.now + shift_time + latency_msg_link

                   

                    self.last_busy_time[link] = last_used
                   
                    self.env.process(self.__wait_message(message, latency_msg_link, shift_time))
                except:
                    #This fact is produced when a node or edge the topology is changed or disappeared
                    self.logger.warning("The initial path assigned is unreachabled. Link: (%i,%i). Routing a new one. "%(link[0],link[1]))


                    paths, DES_dst = self.selector_path[message.app_name].get_path_from_failure(self, message, link, self.alloc_DES,self.alloc_module, self.last_busy_time,self.env.now)

                    if DES_dst == [] and paths==[]:
                        #Message communication ending:
                        #The message have arrived to the destination node but it is unavailable.
                        None

                        self.logger.debug("\t No path given. Message is lost")
                    else:

                        message.path = copy.copy(paths[0])
                        message.idDES = DES_dst[0]
                        self.logger.debug("(\t New path given. Message is enrouting again.")
                      
                        self.network_ctrl_pipe.put(message)



    def __wait_message(self, msg, latency, shift_time):
        """
        Simulates the transfer behavior of a message on a link
        """
        self.network_pump += 1
        yield self.env.timeout(latency + shift_time)

        self.network_pump -= 1
        self.network_ctrl_pipe.put(msg)
        # self.queue[message.path[0]] -= 1

    def __get_id_process(self):
        """
        A DES-process has an unique identifier
        """
        self.__idProcess += 1
        return self.__idProcess

    def __init_metrics(self):
        """
        Each entity and node metrics are initialized with empty values
        """
        nodes_att = self.topology.get_nodes_att()
        measures = {"node": {}, "link": {}}
        for key in nodes_att:
            measures["node"][key] = {}

        for edge in self.topology.get_edges():
            measures["link"][edge] = {Topology.LINK_PR: self.topology.get_edge(edge)[self.topology.LINK_PR],
                                      Topology.LINK_BW: self.topology.get_edge(edge)[self.topology.LINK_BW]}
        return measures

    def __add_placement_process(self, placement):
        """
        A DES-process who controls the invocation of Placement.run
        """

        myId = self.__get_id_process()
        self.des_process_running[myId] = True
        self.des_control_process[placement.name]=myId



        self.logger.debug("Added_Process - Placement Algorithm\t#DES:%i" % myId)
        while not self.stop and self.des_process_running[myId]:
            x = placement.get_next_activation()
           

            yield self.env.timeout(x)
           

            self.source =self.source+1

            placement.run(self)
           
            self.logger.debug("(DES:%i) %7.4f Run - Placement Policy: %s " % (myId, self.env.now, self.stop))  # Rewrite
            # self.sources = []
        self.logger.debug("STOP_Process - Placement Algorithm\t#DES:%i" % myId)

    def __add_population_process(self, population):
        """
        A DES-process who controls the invocation of Population.run
        """
        myId = self.__get_id_process()
        self.des_process_running[myId] = True
        self.des_control_process[population.name] = myId

        self.logger.debug("Added_Process - Population Algorithm\t#DES:%i" % myId)
        while not self.stop and self.des_process_running[myId]:
            yield self.env.timeout(population.get_next_activation())
            self.logger.debug("(DES:%i) %7.4f Run - Population Policy: %s " % (myId, self.env.now, self.stop))  # REWRITE
            self.source = self.source + 1
            population.run(self)
            

            self.placement.run(self)
            self.sources = []


        self.logger.debug("STOP_Process - Population Algorithm\t#DES:%i" % myId)

    def __getIDMessage(self):
        self.__idMessage +=1
        return self.__idMessage


    def __add_source_population(self, idDES, name_app, message, distribution):
        """
        A DES-process who controls the invocation of several Pure Source Modules
        """

    
        self.logger.debug("Added_Process - Module Pure Source\t#DES:%i" % idDES)

        while not self.stop and self.des_process_running[idDES]:

            nextTime = distribution.next()


            yield self.env.timeout(nextTime)

            if self.des_process_running[idDES]:


                self.logger.debug("(App:%s#DES:%i)\tModule - Generating Message: %s \t(T:%d)" % (name_app, idDES, message.name,self.env.now))

                msg = copy.copy(message)
                msg.timestamp = self.env.now

                msg.id = self.__getIDMessage()
        

                

                self.__send_message(name_app, msg, idDES, self.SOURCE_METRIC)



        self.logger.debug("STOP_Process - Module Pure Source\t#DES:%i" % idDES)

    def __update_node_metrics(self, app, module, message, des, type):
        try:

            self.queue[message.path[0]] -=1
            if "M.A" in message.name:
               if message.timestamp < self.lasttime:
                   self.done.append(message.id)
            if message.id not in self.done:
        

                """
                It computes the service time in processing a message and record this event
                """
                if module in self.apps[app].get_sink_modules():

                    """
                    The module is a SINK (Actuactor)
                    """
                 
                    id_node  = self.DES_msgs[message.id]
             =
                    time_service = 0
                else:

                    """
                    The module is a processing module
                    """
           
                 
                    id_node = self.alloc_msgs[message.id]
      

                    
                    

                    att_node = self.topology.get_nodes_att()[id_node]
                    time_service = message.inst / float(att_node["IPT"])

                
                """
                it records the entity.id who sends this message
                """
              



                #WARNING. If there are more than two equal modules deployed in the same entity, it will not be possible to determine which process sent this package at this point. That information will have to be calculated by the trace of the message (message.id)



                if "M.B" in message.name:
                   time_emmitted = self.timestamps[message.id][0]

                elif "M.C" in message.name:
                    time_emmitted = self.timestamps[message.id][1]
                elif "M.D" in message.name:
                    time_emmitted = self.timestamps[message.id][2]
                else:
                    time_emmitted = float(message.timestamp)

              
                sourceDES = self.DES_msgs[message.id]

                link = (message.path[0], id_node)
                try:

                    x = self.busy_module[id_node]
                except:
                    self.busy_module[id_node]= 0

                if  self.busy_module[id_node] <  float(message.timestamp_rec):
                    

                    time_in = float(message.timestamp_rec)
                else:

                    time_in =   self.busy_module[id_node]

                
                self.metrics.insert(
                    {"id":message.id,"type": message.id, "app": app, "module": module, "message": message.name,
                     "DES.src": sourceDES, "DES.dst":des,"module.src": message.src,
                     "TOPO.src": message.path[0], "TOPO.dst": id_node,

                     "service": time_service, "time_in": time_in,
                     "time_out": time_service +time_in, "time_emit": time_emmitted,
                     "time_reception": float(message.timestamp_rec)

                     })

                if "M.A" in message.name:
                    self.timestamps[message.id].append(time_service +time_in)
                elif  "M.B" in message.name:
                    self.timestamps[message.id].append(time_service +time_in)
                elif "M.C" in message.name:
                    self.timestamps[message.id].append(time_service + time_in)
                elif "M.D" in message.name:
                    self.timestamps[message.id].append(time_service + time_in)
                self.busy_module[id_node]=time_service + time_in
               
                self.lasttime = message.timestamp
                return time_service
        except KeyError:
           
            self.logger.debug("Updating node metrics - Node removed: DES:%i" % des)
            return 0
       
    """
    MEJORAR - ASOCIAR UN PROCESO QUE LOS CONTROLES®.
    """

    def __add_up_node_process(self, next_event, **param):

        myId = self.__get_id_process()
        self.logger.debug("Added_Process - UP entity Creation\t#DES:%i" % myId)
        while not self.stop:
            # TODO Define function to ADD a new NODE in topology
            yield self.env.timeout(next_event(**param))
            self.logger.debug("(DES:%i) %7.4f Node " % (myId, self.env.now))
        self.logger.debug("STOP_Process - UP entity Creation\t#DES%i" % myId)

    """
    MEJORAR - ASOCIAR UN PROCESO QUE LOS CONTROLES.
    """

    def __add_down_node_process(self, next_event, **param):
        myId = self.__get_id_process()
        self.des_process_running[myId] = True
        self.logger.debug("Added_Process - Down entity Creation\t#DES:%i" % myId)
        while not self.stop and self.des_process_running[myId]:
            yield self.env.timeout(next_event(**param))
            self.logger.debug("(DES:%i) %7.4f Node " % (myId, self.env.now))

        self.logger.debug("STOP_Process - Down entity Creation\t#DES%i" % myId)

    def __add_source_module(self, idDES, app_name, module, message, distribution, **param):
        """
        It generates a DES process associated to a compute module for the generation of messages
        """
        self.logger.debug("Added_Process - Module Source: %s\t#DES:%i" % (module, idDES))
        while (not self.stop) and self.des_process_running[idDES]:
            yield self.env.timeout(distribution.next())
            if self.des_process_running[idDES]:
                self.logger.debug(
                    "(App:%s#DES:%i#%s)\tModule - Generating Message:\t%s" % (app_name, idDES, module, message.name))
                msg = copy.copy(message)
                msg.timestamp = self.env.now
         
                self.__send_message(app_name, msg, idDES,self.SOURCE_METRIC)

        self.logger.debug("STOP_Process - Module Source: %s\t#DES:%i" % (module, idDES))


    def __add_consumer_module(self, ides, app_name, module, register_consumer_msg):
        """
        It generates a DES process associated to a compute module
        """


        self.logger.debug("Added_Process - Module Consumer: %s\t#DES:%i" % (module, ides))
        while not self.stop and self.des_process_running[ides]:
            if self.des_process_running[ides]:

                msg = yield self.consumer_pipes["%s%s%i"%(app_name,module,ides)].get()
               
               
                m = self.apps[app_name].services[module]

              
               
                doBefore = False
                for register in register_consumer_msg:

                    if msg.name == register["message_in"].name:


                        # The message can be treated by this module
                        """
                        Processing the message
                        """

                        # print "Consumer Message: %d " % self.env.now
                        # print "MODULE DES: ",ides
                        # print "id ",msg.id
                        # print "name ",msg.name
                        # print msg.path
                        # print msg.dst_int
                        # print msg.timestamp
                        # print msg.dst
                        #
                        # print "-" * 30

                        #The module only computes this type of message one time.
                        #It records once
                        if not doBefore :
                            try:
                                type = self.NODE_METRIC
                                # for i in range(0,msg):
                                service_time = self.__update_node_metrics(app_name, module, msg, ides, type)
                                yield self.env.timeout(service_time)
                                doBefore = True
                            except:
                                print("")

                        """
                        Transferring the message
                        """
                        if not register["message_out"]:

                            """
                            Sink behaviour (nothing to send)
                            """
                            self.logger.debug(
                                "(App:%s#DES:%i#%s)\tModule - Sink Message:\t%s" % (app_name, ides, module, msg.name))
                            continue
                        else:


                            if register["dist"](**register["param"]): ### THRESHOLD DISTRIBUTION to Accept the message from source
                                if not register["module_dest"]:

                                    # it is not a broadcasting message
                                    self.logger.debug("(App:%s#DES:%i#%s)\tModule - Transmit Message:\t%s" % (
                                        app_name, ides, module, register["message_out"].name))


                                    msg_out = copy.copy(register["message_out"])
                                    msg_out.timestamp = self.env.now
                                    msg_out.id = msg.id
                                    msg_out.last_idDes = copy.copy(msg.last_idDes)
                                    msg_out.last_idDes.append(ides)

                                

                                    self.__send_message(app_name, msg_out,ides, self.FORWARD_METRIC)
                          


                                else:
                                    # it is a broadcasting message
                                    self.logger.debug("(App:%s#DES:%i#%s)\tModule - Broadcasting Message:\t%s" % (
                                        app_name, ides, module, register["message_out"].name))

                                    msg_out = copy.copy(register["message_out"])
                                    msg_out.timestamp = self.env.now
                                    msg_out.last_idDes = copy.copy(msg.last_idDes)
                                    msg_out.id = msg.id
                                    msg_out.last_idDes = msg.last_idDes.append(ides)
                                    for idx, module_dst in enumerate(register["module_dest"]):
                                        if random.random() <= register["p"][idx]:

                                            self.__send_message(app_name, msg_out, ides,self.FORWARD_METRIC)

                            else:
                                self.logger.debug("(App:%s#DES:%i#%s)\tModule - Stopped Message:\t%s" % (
                                    app_name, ides, module, register["message_out"].name))


        self.logger.debug("STOP_Process - Module Consumer: %s\t#DES:%i" % (module, ides))

    def __add_sink_module(self, ides, app_name, module):
        """
        It generates a DES process associated to a SINK module
        """
        self.logger.debug("Added_Process - Module Pure Sink: %s\t#DES:%i" % (module, ides))
        while not self.stop and self.des_process_running[ides]:
            msg = yield self.consumer_pipes["%s%s%i" % (app_name, module, ides)].get()
            """
            Processing the message
            """
            # self.logger.debug(
            #     "(App:%s#DES:%i#%s)\tModule - Sink Message:\t%s" % (app_name, ides, module, msg.name))
            type = self.SINK_METRIC
            service_time = self.__update_node_metrics(app_name, module, msg, ides, type)
            yield self.env.timeout(service_time)  # service time is 0
        self.logger.debug("STOP_Process - Module Pure Sink: %s\t#DES:%i" % (module, ides))


    def __add_stop_monitor(self, name, function, distribution,show_progress_monitor, **param):
        """
        Add a DES process for Stop/Progress bar monitor
        """
        myId = self.__get_id_process()
        self.logger.debug("Added_Process - Internal Monitor: %s\t#DES:%i" % (name,myId))
        if show_progress_monitor:
            self.pbar = tqdm(total=self.until)
        while not self.stop:
            yield self.env.timeout(distribution.next())
            function(show_progress_monitor,**param)
        self.logger.debug("STOP_Process - Internal Monitor: %s\t#DES:%i" % (name, myId))


    def __add_monitor(self, name, function, distribution, **param):
        """
        Add a DES process for user purpose
        """
        myId = self.__get_id_process()
        self.logger.debug("Added_Process - Internal Monitor: %s\t#DES:%i" % (name, myId))
        while not self.stop:
            yield self.env.timeout(distribution.next())
            function(**param)
        self.logger.debug("STOP_Process - Internal Monitor: %s\t#DES:%i" % (name, myId))


    def __add_consumer_service_pipe(self,app_name,module,idDES):
        self.logger.debug("Creating PIPE: %s%s%i "%(app_name,module,idDES))

        self.consumer_pipes["%s%s%i"%(app_name,module,idDES)] = simpy.Store(self.env)



    def __ctrl_progress_monitor(self,show_progress_monitor,time_shift):
        """
        The *simpy.run.until* function doesnot stop the execution until all pipes are empty.
        We force the stop our DES process using *self.stop* boolean

        """
        if self.until:
            if show_progress_monitor:
                self.pbar.update(time_shift)
            if self.env.now >= self.until:
                self.stop = True
                if show_progress_monitor:
                    self.pbar.close()
                self.logger.info("! Stop simulation at time: %f !" % self.env.now)

    """
    DEPRECATED
    """
    def __update_internal_structures_from_DES_remove(self, DES):
        try:
            self.alloc_DES.pop(DES, None)
            for app in self.alloc_module:
                for module in self.alloc_module[app]:
                    self.alloc_module[app][module].remove(DES)
        except:
            None


    """
    SECTION FOR PUBLIC METHODS
    """

    def get_DES(self,name):
        return self.des_control_process[name]

    def deploy_monitor(self, name, function, distribution, **param):
        """
        Add a DES process for user purpose

        Args:
            name (string) name of monitor

            function (function): function that will be invoked within the simulator with the user's code

            distribution (function): a temporary distribution function

        Kwargs:
            param (dict): the parameters of the *distribution* function

        """
        self.env.process(self.__add_monitor(name, function, distribution, **param))

    def register_event_entity(self, next_event_dist, event_type=EVENT_UP_ENTITY, **args):
        """
        TODO
        """
        if event_type == EVENT_UP_ENTITY:
            self.env.process(self.__add_up_node_process( next_event_dist, **args))
        elif event_type == EVENT_DOWN_ENTITY:
            self.env.process(self.__add_down_node_process( next_event_dist, **args))

    def deploy_source(self, app_name, id_node, msg, distribution):

        """
        Add a DES process for deploy pure source modules (sensors)
        This function its used by (:mod:`Population`) algorithm

        Args:
            app_name (str): application name

            id_node (int): entity.id of the topology who will create the messages

            distribution (function): a temporary distribution function

        Kwargs:
            param - the parameters of the *distribution* function

        Returns:
            id (int) the same input *id*

        """
        idDES = self.__get_id_process()
        self.des_process_running[idDES] = True
        
        self.env.process(self.__add_source_population(idDES, app_name, msg, distribution))
        
        self.alloc_DES[idDES] = id_node
        
        self.alloc_source[idDES] = {"id":id_node,"app":app_name,"module":msg.src,"name":msg.name}
        return idDES



    def __deploy_source_module(self, app_name, module, id_node, msg, distribution):
        """
        Add a DES process for deploy  source modules
        This function its used by (:mod:`Population`) algorithm

        Args:
            app_name (str): application name

            id_node (int): entity.id of the topology who will create the messages

            distribution (function): a temporary distribution function

        Kwargs:
            param - the parameters of the *distribution* function

        Returns:
            id (int) the same input *id*

        """
 

        idDES = self.__get_id_process()
        self.des_process_running[idDES] = True
        self.env.process(self.__add_source_module(idDES, app_name, module,msg, distribution))

        self.alloc_DES[idDES] = id_node
        return idDES

    # idsrc = sim.deploy_module(app_name, module, id_node, register_consumer_msg)
    def __deploy_module(self, app_name, module, id_node, register_consumer_msg):

        """
        Add a DES process for deploy  modules
        This function its used by (:mod:`Population`) algorithm

        Args:
            app_name (str): application name

            id_node (int): entity.id of the topology who will create the messages

            module (str): module name

            msg (str): message?

        Kwargs:
            param - the parameters of the *distribution* function

        Returns:
            id (int) the same input *id*

        """

        idDES = self.__get_id_process()


        self.des_process_running[idDES] = True


        self.__add_consumer_service_pipe(app_name, module, idDES)
        self.alloc_DES[idDES] = id_node
        self.env.process(self.__add_consumer_module(idDES,app_name, module,register_consumer_msg))
        # To generate the QUEUE of a SERVICE module
        # if module == "R":








        if module not in self.alloc_module[app_name]:


            self.alloc_module[app_name][module] = []

        self.alloc_module[app_name][module].append(idDES)



        return idDES


    def deploy_sink(self, app_name, node, module):
        """
        Add a DES process for deploy pure SINK modules (actuators)
        This function its used by (:mod:`Placement`): algorithm
        Internatlly, there is not a DES PROCESS for this type of behaviour
        Args:
            app_name (str): application name

            node (int): entity.id of the topology who will create the messages

            module (str): module
        """
        idDES = self.__get_id_process()
        self.des_process_running[idDES] = True
        self.alloc_DES[idDES] = node
        self.__add_consumer_service_pipe(app_name, module, idDES)
        # Update the relathionships among module-entity
        if app_name in self.alloc_module:
            if module not in self.alloc_module[app_name]:
                self.alloc_module[app_name][module] = []
        self.alloc_module[app_name][module].append(idDES)
        self.env.process(self.__add_sink_module(idDES,app_name, module))



    def stop_process(self, id):
        """
        All pure source modules (sensors) are controlled by this boolean.
        Using this function (:mod:`Population`) algorithm can stop one source

        Args:
            id.source (int): the identifier of the DES process.
        """
        self.des_process_running[id] = False

    def start_process(self, id):
        """
        All pure source modules (sensors) are controlled by this boolean.
        Using this function (:mod:`Population`) algorithm can start one source

        Args:
            id.source (int): the identifier of the DES process.
        """
        self.des_process_running[id] = True





    def deploy_app(self, app, placement, population, selector):
        """
        This process is responsible for linking the *application* to the different algorithms (placement, population, and service)

        Args:
            app (object): :mod:`Application` class

            placement (object): :mod:`Placement` class

            population (object): :mod:`Population` class

            selector (object): :mod:`Selector` class
        """
        # Application

        self.app = app

        self.apps[app.name] = app

        self.placement = placement
        self.population = population
        # Initialization
        self.alloc_module[app.name] = {}

        # Add Placement controls to the App
        if not placement.name in self.placement_policy.keys():  # First Time
            self.placement_policy[placement.name] = {"placement_policy": placement, "apps": []}
            if placement.activation_dist is not None:
                self.env.process(self.__add_placement_process(placement))
        self.placement_policy[placement.name]["apps"].append(app.name)

        # Add Population control to the App

        if not population.name in self.population_policy.keys():  # First Time
            self.population_policy[population.name] = {"population_policy": self.population, "apps": []}
            if population.activation_dist is not None:
                self.env.process(self.__add_population_process(self.population))
        self.population_policy[population.name]["apps"].append(app.name)

        # Add Selection control to the App
        self.selector_path[app.name] = selector

    def get_alloc_entities(self):

        alloc_entities = {}
        for key in self.topology.nodeAttributes.keys():
            alloc_entities[key] = []

        for id_des_process in self.alloc_source:
            src_deployed = self.alloc_source[id_des_process]
            # print "Module (SRC): %s(%s) - deployed at entity.id: %s" %(src_deployed["module"],src_deployed["app"],src_deployed["id"])
            alloc_entities[src_deployed["id"]].append(src_deployed["app"]+"#"+src_deployed["module"])

        for app in self.alloc_module:
            for module in self.alloc_module[app]:

                # print "Module (MOD): %s(%s) - deployed at entities.id: %s" % (module,app,self.alloc_module[app][module])
                for idDES in self.alloc_module[app][module]:
                    alloc_entities[self.alloc_DES[idDES]].append(app+"#"+module)

        return alloc_entities

    def deploy_module(self,app_name,module, services,ids):

        register_consumer_msg = []
        id_DES =[]


        # print module
        for service in services:
            """
            A module can manage multiples messages as well as pass them as create them.
            """
            if service["type"] == Application.TYPE_SOURCE:


                """
                The MODULE can generate messages according with a distribution:
                It adds a DES process for mananging it:  __add_source_module
                """
                for id_topology in ids:
                    id_DES.append(self.__deploy_source_module(app_name, module, distribution=service["dist"],
                                                     msg=service["message_out"],
                                                     id_node=id_topology))
            else:

                """
                The MODULE can deal with different messages, "tuppleMapping (iFogSim)",
                all of them are add a list to be managed in only one DES process
                MODULE TYPE CONSUMER : adding process:  __add_consumer_module
                """
                #work here
                # 1 module puede consumir N type de messages con diferentes funciones de distribucion
                register_consumer_msg.append(
                    {"message_in": service["message_in"], "message_out": service["message_out"],
                     "module_dest": service["module_dest"], "dist": service["dist"], "param": service["param"]})

        if len(register_consumer_msg) > 0:
            for id_topology in ids:

                id_DES.append(self.__deploy_module(app_name, module, id_topology, register_consumer_msg))



    def remove_node(self, id_node_topology):
        # Stopping related processes deployed in the module and clearing main structure: alloc_DES
        des_tmp=[]
        if id_node_topology in self.alloc_DES.values():
            for k, v in self.alloc_DES.items():
                if v == id_node_topology:
                    des_tmp.append(k)
                    self.stop_process(k)
                    del self.alloc_DES[k]

        # Clearing other related structures
        for k, v in self.alloc_module.items():
            for k2, v2 in self.alloc_module[k].items():
                for item in des_tmp:
                    if item in v2:
                        v2.remove(item)

        # Finally removing node from topology
        self.topology.G.remove_node(id_node_topology)

    def draw_allocated_topology(self):
        entities = self.get_alloc_entities()
        utils.draw_topology(self.topology,entities)

    def get_assigned_structured_modules_from_DES(self):
        fullAssignation = {}

        for app in self.alloc_module:
            for module in self.alloc_module[app]:
                deployed = self.alloc_module[app][module]
                for des in deployed:
                    fullAssignation[des] = {"DES": self.alloc_DES[des], "module": module}
        return fullAssignation


    def print_debug_assignaments(self):
        """
        This functions prints debug information about the assignment of DES process - Topology ID - Source Module or Modules
        """
        fullAssignation = {}

        for app in self.alloc_module:
            for module in self.alloc_module[app]:
                deployed = self.alloc_module[app][module]
                for des in deployed:
                    fullAssignation[des] = {"ID":self.alloc_DES[des],"Module":module} #DES process are unique for each module/element

        print "-"*40
        print "DES\t| TOPO \t| Src.Mod \t| Modules"
        print ("-" * 40)
        for k in self.alloc_DES:
            print k,"\t|",self.alloc_DES[k],"\t|",self.alloc_source[k]["name"] if k in self.alloc_source.keys() else "--","\t\t|",fullAssignation[k]["Module"] if k in fullAssignation.keys() else "--"
        print "-" * 40
        # exit()


    def run(self, until,alpha,test_initial_deploy=False,show_progress_monitor=True):
        """
        Start the simulation

        Args:
            until (int): Defines a stop time. If None the simulation runs until some internal algorithm changes the var *yafs.core.sim.stop* to True
        """
        self.alpha = alpha
        self.env.process(self.__network_process())
    
        """
        
        Creating app.sources and deploy the sources in the topology
        """
        for pop in self.population_policy.itervalues():
            for app_name in pop["apps"]:

                pop["population_policy"].initial_allocation(self, app_name)

        """
        Creating initial deploy of services
        """
        for place in self.placement_policy.itervalues():

            place["placement_policy"].initial_allocation(self, app_name)  # internally consideres the apps in charge

        """
        A internal DES process to stop the simulation,
        *Simpy.run.until* wait to all pipers are empty. So, hundreds of messages should be service... We force with the stop
        """

        time_shift = 200
        distribution = deterministicDistribution(name="Deterministic", time=time_shift)
        self.env.process(self.__add_stop_monitor("Stop_Control_Monitor",self.__ctrl_progress_monitor,distribution,show_progress_monitor,time_shift=time_shift))




        #self.print_debug_assignaments()


        """
        RUN
        """
        self.until = until
        if not test_initial_deploy:
            self.env.run(until=until) #This does not stop the simpy.simulation at time. We have to force the stop
        file1 = open("Satisfied.txt", "w")
        file1.write(str(self.satisfied))
        file1.close()
        
        self.metrics.close()